﻿using System;
using System.Collections.Generic;
using System.IO;

namespace FileSystemManager
{
    class Program
    {
        static void Main(string[] args)
        {   
            Notifier notifier = new Notifier();

            string startDir = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location); 
            Console.WriteLine($"Starting directory: {startDir}");
            Console.WriteLine();

            var visitor = new FileSystemVisitor(startDir, FileSystemVisitor.SearchAction.GoOn, x => x.Extension == ".dll");
            RegisterEvents(visitor, notifier);
            var results = visitor.GetEnumerator();
            foreach (var result in visitor)
            {
                System.Console.WriteLine(result);
            }
        }
        private static void RegisterEvents(FileSystemVisitor visitor, Notifier notifier)
        {
            visitor.Start += (sender, eventArgs) => notifier.Start(sender, eventArgs);
            visitor.FileFinded += (sender, eventArgs) => notifier.FileFinded(sender, eventArgs);
            visitor.FilteredFileFinded += (sender, eventArgs) => notifier.FilteredFileFinded(sender, eventArgs);
            visitor.DirectoryFinded += (sender, eventArgs) => notifier.DirectoryFinded(sender, eventArgs);
            visitor.FilteredDirectoryFinded += (sender, eventArgs) => notifier.FilteredDirectoryFinded(sender, eventArgs);
            visitor.Finish += (sender, eventArgs) => notifier.Finish(sender, eventArgs);
            visitor.Skip += (sender, eventArgs) => notifier.Skipped(sender, eventArgs);
        }
    }
}
