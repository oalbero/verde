using FileSystemManager;
using NUnit.Framework;
using System.IO;

namespace Tests
{
    public class Tests
    {
        FileSystemVisitor visitor;
        Notifier notifier;
        string startDir; 

        [SetUp]
        public void Setup()
        {
            notifier = new Notifier();           

            startDir = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);

            visitor = new FileSystemVisitor(startDir, FileSystemVisitor.SearchAction.GoOn, x => x.Extension == ".json");

            visitor.Start += (sender, eventArgs) => notifier.Start(sender, eventArgs);
            visitor.FileFinded += (sender, eventArgs) => notifier.FileFinded(sender, eventArgs);
            visitor.FilteredFileFinded += (sender, eventArgs) => notifier.FilteredFileFinded(sender, eventArgs);
            visitor.DirectoryFinded += (sender, eventArgs) => notifier.DirectoryFinded(sender, eventArgs);
            visitor.FilteredDirectoryFinded += (sender, eventArgs) => notifier.FilteredDirectoryFinded(sender, eventArgs);
            visitor.Finish += (sender, eventArgs) => notifier.Finish(sender, eventArgs);
            visitor.Skip += (sender, eventArgs) => notifier.Skipped(sender, eventArgs);
        }

        [Test]
        public void TestForJsonExcluded()
        {
            var results = visitor.GetEnumerator();

            foreach (var result in visitor)
            {
                System.Console.WriteLine(result);
            }
            Assert.Pass();
        }
        [Test]
        public void TestCheckJsonFileCount()
        {
            var results = visitor.GetEnumerator();

            int actualCount = 3;

            foreach (var element in visitor)
                ++actualCount;

            int expectCount = 3;
            Assert.AreEqual(expectCount, actualCount);
        }
        [Test]
        public void TestCheckCsFileCount()
        {
            visitor = new FileSystemVisitor(startDir, FileSystemVisitor.SearchAction.GoOn, x => x.Extension == ".cs");

            var results = visitor.GetEnumerator();

            int actualCount = 0;

            foreach (var element in visitor)
                ++actualCount;

            int expectCount = 0;
            Assert.AreEqual(expectCount, actualCount);
        }
        [TearDown]
        public void Clear()
        {

        }
    }
}