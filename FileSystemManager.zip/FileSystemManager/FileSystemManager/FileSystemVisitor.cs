﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace FileSystemManager
{
    public class FileSystemVisitor : IEnumerable<FileSystemInfo>
    {
        /*public delegate void SearchStartHandler(object sender, FileSystemEventArgs e);
        public delegate void SearchEndHandler(object sender, FileSystemEventArgs e);
        public delegate void searchResultHandler(object sender, FileSystemEventArgs e);
        public event SearchStartHandler onStart;
        public event SearchEndHandler onEnd;
        public event searchResultHandler onFind;*/

        public event EventHandler<SearchAction> Start;
        public event EventHandler<SearchAction> Finish;
        public event EventHandler<SearchAction> FileFinded;
        public event EventHandler<SearchAction> DirectoryFinded;
        public event EventHandler<SearchAction> FilteredFileFinded;
        public event EventHandler<SearchAction> FilteredDirectoryFinded;
        public event EventHandler<SearchAction> Skip;

        private DirectoryInfo startDir;
        private Func<FileSystemInfo, bool> filterBy;
        SearchAction currentAction;
                
        public FileSystemVisitor(string startPoint, SearchAction action)
        {
            startDir =  new DirectoryInfo(startPoint);
            currentAction = action;
        }
        public FileSystemVisitor(string startPoint, SearchAction action, Func<FileSystemInfo, bool> filter = null)
        {
            startDir = new DirectoryInfo(startPoint);
            filterBy = filter;
            currentAction = action;
        }       
         public IEnumerator<FileSystemInfo> GetEnumerator()
        {
            if (currentAction == SearchAction.Stop)
            {
                Console.WriteLine("Search ended");
                yield break;
            }
            OnEvent(Start, currentAction);
           
            if (currentAction != SearchAction.Skip)
            {
                if (filterBy(startDir))
                    yield return startDir;
                foreach (DirectoryInfo d in startDir.GetDirectories())
                {                    
                    OnEvent(DirectoryFinded, currentAction);
                    if (currentAction == SearchAction.Stop)
                    {
                        Console.WriteLine($"Search ended on {d.Name}");
                        yield break;
                    }
                    if (currentAction == SearchAction.Skip)
                    {
                        Console.WriteLine($"Folder was skipped: {d.Name}");                        
                        continue;
                    }
                    if (filterBy(d))
                    {                        
                        OnEvent(FilteredDirectoryFinded, currentAction);
                        if (currentAction == SearchAction.Stop)
                        {                            
                            Console.WriteLine($"Filtered search ended in {d.Name}");
                            yield break;
                        }
                        if (currentAction == SearchAction.Skip)
                        {
                            Console.WriteLine($"Filtered folder was skipped: {d.Name}");
                            continue;
                        }
                    }
                    var newVisitor = new FileSystemVisitor(d.FullName, currentAction, filterBy);
                    RegisterEvents(newVisitor);
                    foreach (FileSystemInfo info in newVisitor)
                    {
                        if (filterBy(info))
                        {
                            Console.WriteLine($"Filtered search started in {d.FullName} : filter: {filterBy.ToString()} ");
                            yield return info;
                        }
                    }
                }
                foreach (FileInfo f in startDir.GetFiles())
                {
                    OnEvent(FileFinded, currentAction);
                    if (currentAction == SearchAction.Stop)
                    {
                        Console.WriteLine($"Search ended on file {f.Name}");
                        yield break;
                    }
                    if (currentAction == SearchAction.Skip)
                    {
                        Console.WriteLine($"File was skipped: {f.Name}");
                        continue;
                    }
                    if (filterBy(f))
                    {                        
                        OnEvent(FilteredFileFinded, currentAction);
                        if (currentAction == SearchAction.Stop)
                        {                            
                            Console.WriteLine($"Filtered search ended on {f.Name}");
                            yield break;
                        }
                        if (currentAction == SearchAction.Skip)
                        {
                            Console.WriteLine($"Filtered search skipped on {f.Name}");
                            continue;
                        }
                        yield return f;
                    }
                }
            }            
            OnEvent(Finish, currentAction);
            if (currentAction == SearchAction.Stop)
            {
                Console.WriteLine("Search ended.");
                yield break;
            }
        }
        protected void OnEvent(EventHandler<SearchAction> action, SearchAction step)
        {
            var tmp = action;
            if (tmp != null)
            {
                tmp(this, step);
            }
        }
        /*protected void OnEvent(EventHandler<SearchAction> action, FileSystemEventArgs step)
        {
            var tmp = action;
            if (tmp != null)
            {
                tmp(this, step);
            }
        }*/
        private void RegisterEvents(FileSystemVisitor visitor)
        {
            visitor.Start = this.Start;
            visitor.Finish = this.Finish;
            visitor.FileFinded = this.FileFinded;
            visitor.FilteredFileFinded = this.FilteredFileFinded;
            visitor.DirectoryFinded = this.DirectoryFinded;
            visitor.FilteredDirectoryFinded = this.FilteredDirectoryFinded;
        }
        private class CurrentAction
        {
            public SearchAction Action { get; set; }
            public static CurrentAction ContinueSearch
                => new CurrentAction { Action = SearchAction.GoOn };
        }        
        public enum SearchAction
        {
            GoOn = 1,
            Skip = 2,
            Stop = 3
        }
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
    }
}
