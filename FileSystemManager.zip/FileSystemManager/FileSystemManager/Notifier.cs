﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FileSystemManager
{
    public class Notifier
    {
        public void Start(object sender, FileSystemVisitor.SearchAction e)
        {
            Console.WriteLine($"Search started in: {e}"); //{e.FullPath}");            
        }
        public void Finish(object sender, FileSystemVisitor.SearchAction e)
        {
            Console.WriteLine($"Search ended in: {e}");
        }
        public void FileFinded(object sender, FileSystemVisitor.SearchAction e)
        {
            Console.WriteLine($"Found file: {e}");
        }
        public void FilteredFileFinded(object sender, FileSystemVisitor.SearchAction e)
        {
            Console.WriteLine($"Found filtered file: {e}");
        }
        public void DirectoryFinded(object sender, FileSystemVisitor.SearchAction e)
        {
            Console.WriteLine($"Found directory: {e}");
        }
        public void FilteredDirectoryFinded(object sender, FileSystemVisitor.SearchAction e)
        {
            Console.WriteLine($"Found filtered directory: {e}");
        }
        public void Skipped(object sender, FileSystemVisitor.SearchAction e)
        {
            Console.WriteLine($"Directory skipped: {e}");
        }
    }
}
