﻿using System;

namespace TimeHelper
{
    public class Clocker
    {        
        public Clocker()
        {

        }        
        public static string MakeHelloAtTime(string name)
        {
            string time = DateTime.Now.ToShortTimeString();
            return $"{time} Hello {name}!"; 
        }
    }
}
