﻿using System;
using TimeHelper;

namespace IntroConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"Hello {args[0]}!");
            Console.WriteLine("Calling Clocker....");
            Console.WriteLine(Clocker.MakeHelloAtTime(args[0]));
        }
    }
}
