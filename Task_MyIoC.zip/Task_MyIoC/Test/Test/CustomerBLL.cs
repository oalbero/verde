﻿using MyIoC;
using System;
using System.Collections.Generic;
using System.Text;

namespace Test
{
    [ImportConstructor]
    public class CustomerBLL
    {
        public CustomerBLL(ICustomerDAL dal, Logger logger)
        {
            Console.WriteLine(Name);
        }
        public string Name = "Customer John Doe";
    }

    [ImportConstructor]
    public class CustomerBLL2
    {
        public CustomerBLL2(ICustomerDAL dal, Logger logger)
        { }
        [Import]
        public ICustomerDAL CustomerDAL { get; set; }
        [Import]
        public Logger Logger { get; set; }
        [Import]
        public string Name = "Customer Jane Doe";
    }
}
