﻿using MyIoC;
using System;
using System.Collections.Generic;
using System.Text;

namespace Test
{
    [ImportConstructor]
    public class CustomerBLL
    {
        public CustomerBLL(ICustomerDAL dal, Logger logger)
        {
            Console.WriteLine(Name);
            CustomerDAL = dal;
            Logger = logger;
        }
        public string Name = "Customer John Doe";
        public ICustomerDAL CustomerDAL { get; set; }
        public Logger Logger { get; set; }
    }

    public class CustomerBLL2
    {
        public CustomerBLL2()
        {
            Console.WriteLine(Name);            
        }
        [Import]
        public ICustomerDAL CustomerDAL { get; set; }
        [Import]
        public Logger Logger { get; set; }

        public string Name = "Customer Jane Doe 2";
    }
}
