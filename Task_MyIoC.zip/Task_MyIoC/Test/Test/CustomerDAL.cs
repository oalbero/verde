﻿using MyIoC;
using System;
using System.Collections.Generic;
using System.Text;

namespace Test
{
    public interface ICustomerDAL
    {
        void Initialization();
    }

    [Export(typeof(ICustomerDAL))]
    public class CustomerDAL : ICustomerDAL
    {
        public CustomerDAL()
        {
            
        }
        public void Initialization()
        {
            Console.WriteLine(Data);
        }

        private string Data = "Customer data initialization...";
    }
}
