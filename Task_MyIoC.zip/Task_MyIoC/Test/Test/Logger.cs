﻿using MyIoC;
using System;
using System.Collections.Generic;
using System.Text;

namespace Test
{
    [Export]
    public class Logger
    {
        public void Log()
        {
            Console.WriteLine(Message);
        }
        public string Message = "Log started";
    }
}
