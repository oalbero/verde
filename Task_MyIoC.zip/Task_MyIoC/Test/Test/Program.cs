﻿using MyIoC;
using System;
using System.Reflection;

namespace Test
{
    class Program
    {
        static ContainerActivator activator;
        static MyIoC.Container container;
        static void Main(string[] args)
        {
            activator = new ContainerActivator();
            Setup();
        }
        public static void Setup()
        {
            container = new MyIoC.Container(activator);
            container.AddAssembly(Assembly.GetExecutingAssembly());

            var customerBLL2 = (CustomerBLL2)container.CreateInstance(typeof(CustomerBLL2));
            var customerBLL = container.CreateInstance<CustomerBLL>();
            var logger = container.CreateInstance<Logger>();
            var customerDAL = container.CreateInstance<ICustomerDAL>();

            Console.WriteLine($"Calling {customerBLL}\n");

            Console.WriteLine($"Calling {customerBLL2}");
            Console.WriteLine(customerBLL2.Name);

            Console.WriteLine($"\nCalling {customerDAL}");
            customerDAL.Initialization();

            Console.WriteLine($"\nCalling {logger}");
            logger.Log();
        }
    }
}
