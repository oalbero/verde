﻿using MyIoC;
using System;
using System.ComponentModel;
using System.Reflection;

namespace Test
{
    class Program
    {
        static ContainerActivator activator;
        static MyIoC.Container container;
        static void Main(string[] args)
        {
            activator = new ContainerActivator();
            Setup();
        }
        public static void Setup()
        {
            container = new MyIoC.Container(activator);
            container.AddAssembly(Assembly.GetExecutingAssembly());

            var customerBLL = (CustomerBLL2)container.CreateInstance(typeof(CustomerBLL2));
            var customerBLL2 = container.CreateInstance<CustomerBLL2>();

            container.AddType(typeof(CustomerBLL2));
            container.AddType(typeof(Logger));
            container.AddType(typeof(CustomerDAL), typeof(ICustomerDAL));
        }
    }
}
