﻿using Caching_Tasks;
using Caching_Tasks.CacheItems;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NorthwindLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Caching_Tests
{
    [TestClass]
    public class TestEntities
    {
        private readonly string categoriesPrefix = "Cache_Categories";
        private readonly string customersPrefix = "Cache_Customers";
        private readonly string suppliersPrefix = "Cache_Suppliers";
       
        [TestMethod]
        public void CategoriesMemoryCache()
        {
            var memoryEntities = new MemoryEntities<Category>(new MemoryCache<IEnumerable<Category>>(categoriesPrefix));

            for (var i = 0; i < 10; i++)
            {
                Console.WriteLine(memoryEntities.GetEntities().Count());
                Thread.Sleep(100);
            }
        }

        [TestMethod]
        public void CategoriesRedisCache()
        {
            var memoryEntities = new MemoryEntities<Category>(new RedisCache<IEnumerable<Category>>("localhost", categoriesPrefix));

            for (var i = 0; i < 10; i++)
            {
                Console.WriteLine(memoryEntities.GetEntities().Count());
                Thread.Sleep(100);
            }
        }

        [TestMethod]
        public void CustomersMemoryCache()
        {
            var memoryEntities = new MemoryEntities<Customer>(new MemoryCache<IEnumerable<Customer>>(customersPrefix));

            for (var i = 0; i < 10; i++)
            {
                Console.WriteLine(memoryEntities.GetEntities().Count());
                Thread.Sleep(100);
            }
        }

        [TestMethod]
        public void CustomersRedisCache()
        {
            var memoryEntities = new MemoryEntities<Customer>(new RedisCache<IEnumerable<Customer>>("localhost", customersPrefix));

            for (var i = 0; i < 10; i++)
            {
                Console.WriteLine(memoryEntities.GetEntities().Count());
                Thread.Sleep(100);
            }
        }

        [TestMethod]
        public void SuppliersMemoryCache()
        {
            var memoryEntities = new MemoryEntities<Supplier>(new MemoryCache<IEnumerable<Supplier>>(suppliersPrefix));

            for (var i = 0; i < 10; i++)
            {
                Console.WriteLine(memoryEntities.GetEntities().Count());
                Thread.Sleep(100);
            }
        }

        [TestMethod]
        public void SuppliersRedisCache()
        {
            var memoryEntities = new MemoryEntities<Supplier>(new RedisCache<IEnumerable<Supplier>>("localhost", suppliersPrefix));

            for (var i = 0; i < 10; i++)
            {
                Console.WriteLine(memoryEntities.GetEntities().Count());
                Thread.Sleep(100);
            }
        }

        [TestMethod]
        public void SqlMonitorsTest()
        {
            var entitiesManager = new MemoryEntitiesMonitor<Supplier>(new MemoryCache<IEnumerable<Supplier>>(suppliersPrefix),
                "select [SupplierID],[CompanyName],[ContactName],[ContactTitle],[Address],[City],[Region],[PostalCode],[Country],[Phone],[Fax] from [dbo].[Suppliers]");
            for (var i = 0; i < 10; i++)
            {
                Console.WriteLine(entitiesManager.GetEntities().Count());
                Thread.Sleep(1000);
            }
        }
    }
}
