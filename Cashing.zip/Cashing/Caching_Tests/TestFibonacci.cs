﻿using System;
using System.Threading;
using Caching_Tasks;
using Caching_Tasks.CacheItems;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Caching_Tests
{
    [TestClass]
    public class TestFibonacci
    {
        private string fibonacciPrefix = "fib";

        [TestMethod]
        public void FibonacciMemoryCache()
        {
            var fibonacci = new Fibonacci(new MemoryCache<int>(fibonacciPrefix));

            for (var i = 1; i < 20; i++)
            {
                Console.WriteLine(fibonacci.CalculateFibonacci(i));
                Thread.Sleep(100);
            }
        }

        [TestMethod]
        public void FibonacciRedisCache()
        {
            var fibonacci = new Fibonacci(new RedisCache<int>("localhost", fibonacciPrefix));

            for (var i = 1; i < 20; i++)
            {
                Console.WriteLine(fibonacci.CalculateFibonacci(i));
                Thread.Sleep(100);
            }
        }
    }
}
