﻿using NorthwindLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Data.SqlClient;
using System.Runtime.Caching;

namespace Caching_Tasks
{
    public class MemoryEntitiesMonitor<T> where T : class
    {
        private MemoryCache<IEnumerable<T>> cache;
        private string monitor;

        public MemoryEntitiesMonitor(MemoryCache<IEnumerable<T>> cache, string monitor)
        {
            this.cache = cache;
            this.monitor = monitor;
        }
        public IEnumerable<T> GetEntities()
        {
            Console.WriteLine("Get entities");
            var user = Thread.CurrentPrincipal.Identity.Name;
            var entities = cache.Get(user);

            if (entities == null)
            {
                Console.WriteLine("Getting entities from db directly.");
                string connectionString;
                using (var dbContext = new Northwind())
                {
                    dbContext.Configuration.LazyLoadingEnabled = false;
                    dbContext.Configuration.ProxyCreationEnabled = false;
                    entities = dbContext.Set<T>().ToList();
                    connectionString = dbContext.Database.Connection.ConnectionString;
                }
                SqlDependency.Start(connectionString);
                cache.Set(user, entities, GetCachePolicy(monitor, connectionString));
            }
            return entities;
        }
        private CacheItemPolicy GetCachePolicy(string monitor, string connectionString)
        {
            return new CacheItemPolicy
            {
                ChangeMonitors = { GetMonitor(monitor, connectionString) }
            };
        }
        private SqlChangeMonitor GetMonitor(string query, string connectionString)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var command = new SqlCommand(query, connection);
                var monitor = new SqlChangeMonitor(new SqlDependency(command));
                command.ExecuteNonQuery();
                return monitor;
            }
        }
    }
}
