﻿using NorthwindLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Caching_Tasks.CacheItems
{
    public class MemoryEntities<T> where T :class
    {
        private readonly ICache<IEnumerable<T>> cache;

        public MemoryEntities(ICache<IEnumerable<T>> cache)
        {
            this.cache = cache;
        }

        public IEnumerable<T> GetEntities()
        {
            Console.WriteLine("Get entities from cache");
            var user = Thread.CurrentPrincipal.Identity.Name;
            var entities = cache.Get(user);

            if (entities == null)
            {
                Console.WriteLine("Get entities from database");
                using (var dbContext = new Northwind())
                {
                    dbContext.Configuration.LazyLoadingEnabled = false;
                    dbContext.Configuration.ProxyCreationEnabled = false;
                    entities = dbContext.Set<T>().ToList();
                }

                cache.Set(user, entities, DateTimeOffset.Now.AddDays(1));
            }
            return entities;
        }
    }
}
