﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Caching_Tasks.CacheItems
{
    public class RedisEntities
    {

    }
}
