﻿using System;
using System.Collections.Generic;
using System.Runtime.Caching;
using System.Text;

namespace Caching_Tasks
{
    public class MemoryCache<T> : ICache<T>
    {
        private ObjectCache cache = MemoryCache.Default;
        private string keyPrefix;

        public MemoryCache(string prefix)
        {
            keyPrefix = prefix;
        }
        public T Get(string key)
        {
            var cachedObject = cache.Get(keyPrefix + key);
            if (cachedObject == null)
            {
                return default(T);
            }
            return (T)cachedObject;
        }
        public void Set(string key, T value, DateTimeOffset expirationDate)
        {
            cache.Set(keyPrefix + key, value, expirationDate);
        }
        public void Set(string key, T value, CacheItemPolicy policy)
        {
            cache.Set(keyPrefix + key, value, policy);
        }
    }
}
