﻿using StackExchange.Redis;
using System;
using System.IO;
using System.Runtime.Serialization;
namespace Caching_Tasks
{
    public class RedisCache<T> : ICache<T>
    {
        private ConnectionMultiplexer redisConnection;
        private string keyPrefix;

        private DataContractSerializer serializer = new DataContractSerializer(typeof(T));

        public RedisCache(string hostName, string prefix)
        {
            keyPrefix = prefix;
            var options = new ConfigurationOptions()
            {
                AbortOnConnectFail = false,
                EndPoints = { hostName }
            };
            redisConnection = ConnectionMultiplexer.Connect(options);
        }
        public T Get(string key)
        {
            var db = redisConnection.GetDatabase();
            byte[] s = db.StringGet(keyPrefix + key);
            if (s == null)
            {
                return default(T);
            }
            return (T)serializer.ReadObject(new MemoryStream(s));
        }
        public void Set(string key, T value, DateTimeOffset expirationDate)
        {
            var db = redisConnection.GetDatabase();
            var redisKey = keyPrefix + key;
            if (value == null)
            {
                db.StringSet(redisKey, RedisValue.Null);
            }
            else
            {
                var stream = new MemoryStream();
                serializer.WriteObject(stream, value);
                db.StringSet(redisKey, stream.ToArray(), expirationDate - DateTimeOffset.Now);
            }
        }
    }
}
