﻿using System;

namespace Caching_Tasks
{
    public interface ICache<T>
    {
        T Get(string key);
        void Set(string key, T value, DateTimeOffset expirationDate);
    }
}
