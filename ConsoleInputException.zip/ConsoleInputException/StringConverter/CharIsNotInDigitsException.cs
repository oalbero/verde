﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StringConverter
{
    public class CharIsNotInDigitsException : Exception
    {
        public CharIsNotInDigitsException(string message) : base(message)
        {

        }
    }
}
