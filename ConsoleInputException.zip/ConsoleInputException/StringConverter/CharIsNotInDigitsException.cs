﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StringConverter
{
    public class CharIsNotInDigitsException : Exception
    {
        private char myChar;
        public CharIsNotInDigitsException(char ch)
        {
            myChar = ch;
            Console.WriteLine($"Char '{ch}' is not found in digits.");
            this.HelpLink = "You should input only numbers!";
        }        
    }
}
