﻿using System;
using System.Linq;

namespace StringConverter
{
    public static class Digitiser
    {
        private static char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        public static void ParseString(string s)
        {
            try
            {
                int i = Convert.ToInt32(s);
                Console.WriteLine($"Converted number: {i}");
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static int CustomConvertString(string s)
        {
            if (string.IsNullOrEmpty(s))
            {
                throw new CharIsNotInDigitsException(char.MinValue);                
            }
            foreach (char ch in s.ToCharArray())
            {
                if (!digits.Contains(ch))
                {
                    Console.WriteLine($"Oops... char...");
                    throw new CharIsNotInDigitsException(ch);
                }
                else
                {
                    Console.WriteLine($"Current digit is {ch}");
                }
            }
            return Convert.ToInt32(s);
        }
        public static int ParseStringToInt(string value)
        {
            int result = 0;
            for (int i = 0; i < value.Length; i++)
            {
                char letter = value[i];
                if (!digits.Contains(letter))
                {
                    Console.WriteLine($"Oops... char...");
                    throw new CharIsNotInDigitsException(letter);
                }
                result = (int) (10 * result + char.GetNumericValue(letter));
            }
            return result;
        }
    }
}
