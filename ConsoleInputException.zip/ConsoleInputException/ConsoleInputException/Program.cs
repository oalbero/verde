﻿using StringConverter;
using System;

namespace ConsoleInputException
{
    class Program
    {
        static void Main(string[] args)
        {
            // Task 1 Checking for empty string
            try
            {
                Console.WriteLine("Input some string, please.");
                Console.WriteLine("Checking for empty string...");
                FirtsSignPrinter.PrintFirstSign(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to show your input of following reason:");
                Console.WriteLine(ex.Message);
            }

            // Task 2 Version 1 
            // Custom string to int converter
            Console.WriteLine(Environment.NewLine);
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Input numbers to convert to int.");
            Digitiser.ParseString(Console.ReadLine());

            // Task  2 Vesrion 2 
            // Custom string to int converter with custom Exception class
            Console.WriteLine(Environment.NewLine);
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Try custom converter and exception.");
            try
            {
                Digitiser.CustomConvertString(Console.ReadLine());
            }
            catch (CharIsNotInDigitsException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
