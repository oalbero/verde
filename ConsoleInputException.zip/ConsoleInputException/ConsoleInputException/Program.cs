﻿using StringConverter;
using System;

namespace ConsoleInputException
{
    class Program
    {
        static void Main(string[] args)
        {
            // Task 1 Corrected version
            // Print each first character of input lines
            try
            {
                Console.WriteLine("Input some string, please.");
                Console.WriteLine("Input 'Exit' to exit.");
                Console.WriteLine("Checking for first letter of input...");

                while (true)
                {
                    string line = Console.ReadLine();
                    if (line == "Exit")
                    {
                        Console.WriteLine("Exiting first task!");
                        break;
                    }
                    else
                    {
                        FirtsSignPrinter.PrintFirstSign(line);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to show your input of following reason:");
                Console.WriteLine(ex.Message);
            }           
            // Task  2 Corrected version 
            // Custom string to int converter with custom Exception class            
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Try custom converter and exception.");
            Console.WriteLine("Input 'Exit' to exit.");
            while (true)
            {
                string line = Console.ReadLine();
                if (line == "Exit")
                {
                    break;
                }
                try
                {
                    int pInt = Digitiser.ParseStringToInt(line);
                    Console.WriteLine($"Your integer is: {pInt}");
                }
                catch (CharIsNotInDigitsException e)
                {
                    Console.WriteLine(e.HelpLink);
                }
            }
            // ==================================================
            // Old solutions
            /*
            // Task 1 Checking for empty string
            try
            {
                Console.WriteLine("Input some string, please.");
                Console.WriteLine("Checking for empty string...");
                FirtsSignPrinter.PrintFirstSign(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to show your input of following reason:");
                Console.WriteLine(ex.Message);
            }
             // Task 2 Version 1 
            // Custom string to int converter
            Console.WriteLine(Environment.NewLine);
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Input numbers to convert to int.");
            Digitiser.ParseString(Console.ReadLine());

            // Task  2 Vesrion 2 
            // Custom string to int converter with custom Exception class
            Console.WriteLine(Environment.NewLine);
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Try custom converter and exception.");
            try
            {
                Digitiser.CustomConvertString(Console.ReadLine());
            }
            catch (CharIsNotInDigitsException e)
            {
                Console.WriteLine(e.Message);
            }

             */
        }
    }
}
