﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleInputException
{
    public static class FirtsSignPrinter
    {
        public static void PrintFirstSign(string input)
        {            
            Console.WriteLine("First sign of your input is...");
            if (input.Trim() == string.Empty)
            {
                Console.WriteLine("Oops");
                throw new Exception("Input string was empty.");
            }
            Console.WriteLine(input[0]);
        }
    }
}
