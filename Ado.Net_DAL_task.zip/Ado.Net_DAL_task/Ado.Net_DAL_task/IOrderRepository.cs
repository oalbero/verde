﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ado.Net_DAL_task
{
    interface IOrderRepository
    {
        IEnumerable<Order> GetOrders();
        CustomOrderDetails GetOrderById(int id);
        int CreateOrder(Order order);
        int UpdateOrder(Order order);
        int DeleteOrder(Order order);
        int SetInProgress(Order order, DateTime? orderDate);
        int SetComplete(Order order, DateTime? shippedDate);
        List<CustomOrderHistory> GetCustomerOrdersHistory(string customerId);
        IList<OrderDetails> GetCustomerOrdersDetail(int orderId);
    }
}
