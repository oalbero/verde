﻿namespace Ado.Net_DAL_task
{
    public class CustomOrderHistory
    {
        public string ProductName { get; set; }
        public int? Total { get; set; }

        public override string ToString()
        {
            return $"ProductName: {ProductName}, Total: {Total}";
        }
    }
}