﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ado.Net_DAL_task
{
    public class Order
    {
        public int OrderID { get; set; }
        public DateTime? OrderDate { get; set; }
        public List<OrderDetails> Details {get; set;}
        public string CustomerID { get; set; }
        public int? EmployeeID { get; set; }
        public DateTime? RequiredDate { get; set; }
        public DateTime? ShippedDate { get; set; }
        public int? ShipVia { get; set; }
        public decimal? Freight { get; set; }
        public string ShipName { get; set; }
        public string ShipAddress { get; set; }
        public string ShipCity { get; set; }
        public string ShipRegion { get; set; }
        public string ShipPostalCode { get; set; }
        public string ShipCountry { get; set; }

        public enum OrderStatuses
        {
            New,
            InProgress,
            Complete
        }       
        public override string ToString()
        {
            return $"OrderId: {OrderID}, CustomerId: {CustomerID}, OrderDate: {OrderDate}, EmployeeId: {EmployeeID}," +
                $"RequiredDate: {RequiredDate}, ShippedDate: {ShippedDate}, Ship Via: {ShipVia}, Freight: {Freight}," +
                $"ShipName: {ShipName}, ShipAddress: {ShipAddress}, ShipCity: {ShipCity}, ShipRegion: {ShipRegion}," +
                $"ShipPostalCode: {ShipPostalCode}, ShipCountry: {ShipCountry} ";
        }

        public OrderStatuses OrderStatus
        {
            get
            {
                if (this.OrderDate == null)
                    return OrderStatuses.New;
                else if (this.ShippedDate == null)
                    return OrderStatuses.InProgress;
                else
                    return OrderStatuses.Complete;
            }
        }
    }
}
