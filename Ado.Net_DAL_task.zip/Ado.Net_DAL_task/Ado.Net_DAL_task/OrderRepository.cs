﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using Serenity.Data;
using System.Data.SqlClient;

namespace Ado.Net_DAL_task
{
    public class OrderRepository : IOrderRepository
    {
        private readonly DbProviderFactory ProviderFactory;
        private readonly string ConnectionString;
        public OrderRepository(string connectionString, string provider)
        {
            ProviderFactory = DbProviderFactories.GetFactory(provider);
            ConnectionString = connectionString;
        }
        public OrderRepository(string connectionString)
        {
            ConnectionString = connectionString;
        }
        // 1.	Показывать список введенных заказов (таблица [Orders]). Помимо основных полей должны возвращаться:
        // a.Статус заказа в виде Enum поля

        public IEnumerable<Order> GetOrders()
        {
            var resultOrders = new List<Order>();
            //using (var connection = ProviderFactory.CreateConnection())
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();

                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "select * from dbo.Orders"; //"select OrderID, OrderDate from dbo.Orders";
                    command.CommandType = CommandType.Text;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            DateTime dataTimeOrder, dataTimeRequired, dataTimeShipped;

                            bool timeOrderFlag = DateTime.TryParse(reader["OrderDate"].ToString(), out dataTimeOrder);
                            bool timeRequiredFlag = DateTime.TryParse(reader["RequiredDate"].ToString(), out dataTimeRequired);
                            bool timeShippedFlag = DateTime.TryParse(reader["ShippedDate"].ToString(), out dataTimeShipped);

                            Order order = new Order()
                            {
                                CustomerID = reader["CustomerID"] == DBNull.Value ? string.Empty : (string)reader["CustomerID"],
                                EmployeeID = (int?)(reader["EmployeeID"]),
                                Freight = (decimal?)(reader["Freight"]),
                                OrderDate = timeOrderFlag ? dataTimeOrder : (DateTime?)null,
                                OrderID = (int)(reader["OrderID"]),
                                RequiredDate = timeRequiredFlag ? dataTimeRequired : (DateTime?)null,
                                ShipAddress = reader["ShipAddress"] ==  DBNull.Value ? string.Empty : (string)reader["ShipAddress"],
                                ShipCity = reader["ShipCity"] == DBNull.Value ? string.Empty : (string)reader["ShipCity"],
                                ShipCountry = reader["ShipCountry"] ==  DBNull.Value ? string.Empty : (string)reader["ShipCountry"],
                                ShipName = reader["ShipName"] == DBNull.Value ? string.Empty : (string)reader["ShipName"],
                                ShippedDate = timeShippedFlag ? dataTimeShipped : (DateTime?)null,
                                ShipPostalCode = reader["ShipPostalCode"] == DBNull.Value ? string.Empty : (string)reader["ShipPostalCode"],
                                ShipRegion = reader["ShipRegion"] == DBNull.Value ? string.Empty : (string)reader["ShipRegion"],
                                ShipVia = (int?)(reader["ShipVia"])
                            };
                            resultOrders.Add(order);
                        }
                    }
                }
            }
            return resultOrders;
        }
        // 2.	Показывать подробные сведения о конкретном заказе, включая номенклатуру заказа 
        // (таблицы [Orders], [Order Details], и [Products], требуется извлекать как Id, так и название продукта)
        public CustomOrderDetails GetOrderById(int id)
        {
            //using (var connection = ProviderFactory.CreateConnection())
            using (var connection = new SqlConnection(ConnectionString))
            {
                CustomOrderDetails details = null;
                connection.ConnectionString = ConnectionString;
                connection.Open();

                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "select od.OrderID, od.ProductID, od.UnitPrice, od.Quantity, od.Discount, p.ProductName from dbo.[Order Details] od inner join dbo.Products p on od.ProductID = p.ProductID where od.OrderID = @id";
                    command.CommandType = CommandType.Text;

                    var paramId = command.CreateParameter();
                    paramId.ParameterName = "@id";
                    paramId.Value = id;
                    command.Parameters.Add(paramId);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            details = new CustomOrderDetails()
                            {
                                Discount = reader["Discount"] ==  DBNull.Value ? 0 : (Single)(reader["Discount"]),
                                OrderID = (int?)(reader["OrderID"]),
                                ProductID = (int?)(reader["ProductID"]),
                                ProductName = reader["ProductName"] == DBNull.Value ? string.Empty : (string)(reader["ProductName"]),
                                Quantity = reader["Quantity"] == DBNull.Value ? short.MinValue : (short)(reader["Quantity"]),
                                UnitPrice = reader["UnitPrice"] ==  DBNull.Value ? 0 : (decimal)(reader["UnitPrice"])
                            };
                        }
                        return details;
                    }
                }
            }
        }
        // 3.	Создавать новые заказы
        public int  CreateOrder(Order order)
        {
            //using (var connection = ProviderFactory.CreateConnection())
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();

                using (var command = connection.CreateCommand())
                {
                    command.CommandText = String.Format("insert into Orders(CustomerID, EmployeeID, OrderDate, RequiredDate, ShippedDate, ShipVia, Freight, ShipName, ShipAddress, ShipCity, ShipRegion, ShipPostalCode, ShipCountry) values ('{0}', {1}, '{2}', '{3}', '{4}', {5}, '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}')",
                        order.CustomerID, order.EmployeeID, order.OrderDate.HasValue ? order.OrderDate.Value.ToString("yyyy-MM-dd HH:mm:ss") : null, order.RequiredDate.HasValue ? order.RequiredDate.Value.ToString("yyyy-MM-dd HH:mm:ss") : null, order.ShippedDate.HasValue ? order.ShippedDate.Value.ToString("yyyy-MM-dd HH:mm:ss") : null, order.ShipVia, order.Freight, order.ShipName, order.ShipAddress, order.ShipCity, order.ShipRegion, order.ShipPostalCode, order.ShipCountry);
                    command.CommandType = CommandType.Text;
                    return command.ExecuteNonQuery();
                }
            }
        }
        // 4.	Менять существующие заказы. При этом:
        // a.Напрямую нельзя менять следующие поля
        //     i.Даты OrderDate и ShippedDate
        //     ii.	Статус заказа
        // b.В заказе со статусом «Новый» можно менять любые поля и состав заказа, за исключением полей, перечисленных в пункте «а».
        // c.В заказе со статусами «В работе» и «Выполненный» нельзя менять ничего
        public int UpdateOrder(Order order)
        {
            //using (var connection = ProviderFactory.CreateConnection())
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();

                using (var command = connection.CreateCommand())
                {

                    command.CommandText = String.Format("update Orders set CustomerID='{0}', EmployeeID='{1}', RequiredDate='{2}', ShipVia='{3}', Freight='{4}', ShipName='{5}', ShipAddress='{6}', ShipCity='{7}', ShipRegion='{8}', ShipPostalCode='{9}', ShipCountry='{10}' where OrderID = {11}",
                    order.CustomerID, order.EmployeeID, order.RequiredDate.HasValue ? order.RequiredDate.Value.ToString("yyyy-MM-dd HH:mm:ss") : null, order.ShipVia, order.Freight, order.ShipName, order.ShipAddress, order.ShipCity, order.ShipRegion, order.ShipPostalCode, order.ShipCountry, order.OrderID);
                    return command.ExecuteNonQuery();
                }
            }
        }
        // 5.	Удалять заказы со статусом «Новый» и «В работе».
        public int  DeleteOrder(Order order)
        {
            //using (var connection = ProviderFactory.CreateConnection())
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = String.Format("delete from Orders where OrderID = {0}", order.OrderID);
                    return command.ExecuteNonQuery();
                }
            }
        }
        // 6.	Менять статус заказа. Для реализации этого пункта предлагается сделать специальные методы (именование выбирайте сами):
        //   a.Передать в работу: устанавливает дату заказа
        //   b.Пометить как выполненный: устанавливает ShippedDate
        public int SetInProgress(Order order, DateTime? orderDate)
        {
            //using (var connection = ProviderFactory.CreateConnection())
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = String.Format("update Orders set OrderDate='{0}' where OrderID = {1}",
                    orderDate.HasValue ? orderDate.Value.ToString("yyyy-MM-dd HH:mm:ss") : null, order.OrderID);
                    return command.ExecuteNonQuery();
                }
            }
        }
        public int SetComplete(Order order, DateTime? shippedDate)
        {
            //using (var connection = ProviderFactory.CreateConnection())
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = String.Format("update Orders set ShippedDate='{0}' where OrderID = {1}",
                        shippedDate.HasValue ? shippedDate.Value.ToString("yyyy-MM-dd HH:mm:ss") : null, order.OrderID);
                    return command.ExecuteNonQuery();
                }
            }
        }
        // 7.	Получать статистику по заказам, используя готовые хранимые процедуры 
        //     a.CustOrderHist
        //     b.CustOrdersDetail
        public List<CustomOrderHistory> GetCustomerOrdersHistory(string customerId)
        {
            var resultOrders = new List<CustomOrderHistory>();
            //using (var connection = ProviderFactory.CreateConnection())
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();

                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "CustOrderHist";
                    command.CommandType = CommandType.StoredProcedure;

                    var paramId = command.CreateParameter();
                    paramId.ParameterName = "@CustomerID";
                    paramId.Value = customerId;
                    paramId.Direction = ParameterDirection.Input;

                    command.Parameters.Add(paramId);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            CustomOrderHistory custHist = new CustomOrderHistory()
                            {
                                ProductName = reader["ProductName"] ==  DBNull.Value ? string.Empty : (string)reader["ProductName"],
                                Total = (int?)(reader["Total"])
                            };
                            resultOrders.Add(custHist);
                        }
                    }    
                }
                return resultOrders;
            }
        }

        public IList<OrderDetails> GetCustomerOrdersDetail(int orderId)
        {
            var resultOrders = new List<OrderDetails>();
            //using (var connection = ProviderFactory.CreateConnection())
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();

                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "CustOrdersDetail";
                    command.CommandType = CommandType.StoredProcedure;

                    var paramId = command.CreateParameter();
                    paramId.ParameterName = "@OrderID";
                    paramId.Value = orderId;
                    paramId.Direction = ParameterDirection.Input;

                    command.Parameters.Add(paramId);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            OrderDetails custDetails = new OrderDetails()
                            {
                                Discount = (int?)reader["Discount"],
                                ExtendedPrice = (decimal?)reader["ExtendedPrice"],
                                ProductName = reader["ProductName"] == DBNull.Value ? string.Empty : (string)reader["ProductName"],
                                Quantity = (short?)(reader["Quantity"]),
                                UnitPrice = (decimal?)(reader["UnitPrice"])
                            };
                            resultOrders.Add(custDetails);
                        }
                    }
                }
                return resultOrders;
            }
        }
    }
}
    
    
