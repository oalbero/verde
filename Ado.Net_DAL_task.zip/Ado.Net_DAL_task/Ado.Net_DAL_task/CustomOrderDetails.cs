﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace Ado.Net_DAL_task
{
    public class CustomOrderDetails
    {
        public int? OrderID { get; set; }
        public int? ProductID { get; set; }
        public decimal UnitPrice { get; set; }
        public short Quantity { get; set; }
        public Single Discount { get; set; }
        public string ProductName { get; set; }

        public override string ToString()
        {
            return $"OrderId: {OrderID}, ProductId: {ProductID}, UnitPrice: {UnitPrice}, " +
                $"Quantity: {Quantity}, Discount: {Discount}, ProductName: {ProductName}";
        }
    }    
}
