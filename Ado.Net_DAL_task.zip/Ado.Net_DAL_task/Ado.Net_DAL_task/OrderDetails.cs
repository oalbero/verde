﻿using System;

namespace Ado.Net_DAL_task
{
    public class OrderDetails
    {
        public decimal? UnitPrice { get; set; }
        public short? Quantity { get; set; }
        public string ProductName { get; set; }
        public int? Discount { get; set; }
        public decimal? ExtendedPrice { get; set; }

        public override string ToString()
        {
            return $"UnitPrice: {UnitPrice}, Quantity: {Quantity}, ProductName: {ProductName}," +
                $"Discount: {Discount}, ExtendedPrice: {ExtendedPrice}";
        }
    }    
}