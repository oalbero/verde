﻿using System;
using System.Configuration;
using Ado.Net_DAL_task;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestDAL
{
    [TestClass]
    public class UnitTest1
    {        
        static string ConnectionString;
        string providerName;

        OrderRepository orderRepository;

        [TestInitialize]
        public void Setup()
        {
            var ConnectionStringItem = ConfigurationManager.ConnectionStrings["NorthwindConnection"];
            //providerName = ConnectionStringItem.ProviderName;
            //orderRepository = new OrderRepository(ConnectionString, providerName);

            ConnectionString = ConnectionStringItem.ConnectionString;
            orderRepository = new OrderRepository(ConnectionString);
        }

        [TestMethod]
        public void TestGetOrders()
        {
            var orderList = orderRepository.GetOrders();
            foreach (Order o in orderList)
            {
                Console.WriteLine(o.ToString());
            }
        }
        [TestMethod]
        public void TestGetOrderById()
        {
            int orderId = 10248;
            CustomOrderDetails order = orderRepository.GetOrderById(orderId);
            Console.WriteLine(order.ToString());
        }
        [TestMethod]
        public void TestCreateOrder()
        {
            Order order = new Order { };
           
            order.CustomerID = "VINET";
            order.EmployeeID = 5;
            order.ShipVia = 3;

            Assert.AreEqual(1, orderRepository.CreateOrder(order));            
        }
        [TestMethod]
        public void TestUpdateOrder()
        {
            Order order = new Order { };
            order.OrderID = 10248;
            order.CustomerID = "VINET";
            order.EmployeeID = 5;
            order.ShipVia = 3;

            Assert.AreEqual(1, orderRepository.UpdateOrder(order));
        }
        [TestMethod]
        public void TestDeleteOrder()
        {
            Order order = new Order { };
            order.OrderID = 11078;

            Assert.AreEqual(0, orderRepository.DeleteOrder(order));
        }
        [TestMethod]
        public void TestSetInProgress()
        {
            Order order = new Order { };
            order.OrderID = 10248;

            Assert.AreEqual(1, orderRepository.SetInProgress(order, DateTime.Now));
        }
        [TestMethod]
        public void TestSetComplete()
        {
            Order order = new Order { };
            order.OrderID = 10248;

            Assert.AreEqual(1, orderRepository.SetComplete(order, DateTime.Now));
        }
        [TestMethod]
        public void TestGetCustomerOrdersHistory()
        {
            string customerId = "VINET";
            var orderList = orderRepository.GetCustomerOrdersHistory(customerId);
            foreach (CustomOrderHistory oh in orderList)
            {
                Console.WriteLine(oh.ToString());
            }
        }
        [TestMethod]
        public void TestGetCustomerOrdersDetail()
        {
            int orderId = 10248;
            var orderList = orderRepository.GetCustomerOrdersDetail(orderId);
            foreach (OrderDetails od in orderList)
            {
                Console.WriteLine(od.ToString());
            }
        }
    }
}
