﻿using MongoDB.Driver;
using System;
using System.Linq;


namespace MongoLister
{
    public class Mongo_db_counter
    {
        public Mongo_db_counter()
        {
            ListDbs();
        }
        public void ListDbs()
        {
            var connectionString = "mongodb://localhost:27017";
            var client = new MongoClient(connectionString);
            var dbList = client.ListDatabases().ToList();

            Console.WriteLine("The list of databases are :");
            foreach (var item in dbList)
            {
                Console.WriteLine(item);
            }

            Console.Read();
        }
    }
}


