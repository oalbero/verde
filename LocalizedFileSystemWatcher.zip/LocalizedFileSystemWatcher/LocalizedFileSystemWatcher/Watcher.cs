﻿using LocalizedFileSystemWatcher.Configuration;
using LocalizedFileSystemWatcher.Resources;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace LocalizedFileSystemWatcher
{
    public class Watcher
    {
        private string startDir;
        private FileSystemWatcher watcher;
        private string filter;
        public bool IsCanceled { get; set; }
        private List<RuleElement> rules;
        private List<DirectoryElement> directories;

        public Watcher(List<DirectoryElement> directories, List<RuleElement> rules)
        {
            this.directories = directories;
            this.rules = rules;
            this.IsCanceled = false;
        }
        public void Watch()
        {
            watcher = new FileSystemWatcher()
            {
                NotifyFilter = NotifyFilters.FileName | NotifyFilters.DirectoryName | NotifyFilters.LastWrite,
                Path = directories.ElementAt(0).DirectoryName,
                IncludeSubdirectories = true,
                EnableRaisingEvents = true
            };

            watcher.Created += OnCreated;
            
            while (!IsCanceled)
            {

            }
        }
        private void OnCreated(object sender, FileSystemEventArgs e)
        {
            int matchCount = 0;
            Console.WriteLine(e.FullPath + " " + Messages.FileCreated);            
            foreach (RuleElement rule in rules)
            {                
                var match = Regex.Match(e.Name, rule.Match);
                if (match.Success && match.Length == e.Name.Length)
                {
                    matchCount++;
                    Console.WriteLine(e.FullPath + " " + Messages.RuleFound + " " + rule.Match);
                    string moveToPath = DevelopPathForRules(rule, e.Name, matchCount);
                    try
                    {
                        if (File.Exists(moveToPath))
                        {
                            File.Delete(moveToPath);
                        }
                        File.Move(e.FullPath, moveToPath);
                        Console.WriteLine(e.FullPath + " " + Messages.FileMoved + " " + moveToPath);
                    }
                    catch (IOException ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }               
            }
            try
            {
                if (File.Exists(e.FullPath))
                {
                    Console.WriteLine(e.FullPath + " " + Messages.NoRuleFound);
                    if (File.Exists(Path.Combine(ConfigParams.DefaultDirectory, e.Name)))
                    {
                        File.Delete(Path.Combine(ConfigParams.DefaultDirectory, e.Name));
                    }
                    File.Move(e.FullPath, Path.Combine(ConfigParams.DefaultDirectory, e.Name));
                    Console.WriteLine(e.FullPath + " " + Messages.FileMovedDefault + " " + ConfigParams.DefaultDirectory+ "\\" + e.Name);
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine();
        }
        private string DevelopPathForRules(RuleElement rule, string fileName, int matchCount)
        {
            string extension = Path.GetExtension(fileName);
            string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(fileName);
            StringBuilder destination = new StringBuilder();
            destination.Append(rule.Destination);
            if (rule.IsIndexAdded)
            {
                destination.Append($"{matchCount}_");
            }
            if (rule.IsTimeMarked)
            {
                var dateTimeFormat = CultureInfo.CurrentCulture.DateTimeFormat;
                dateTimeFormat.DateSeparator = ".";
                destination.Append($"{DateTime.Now.ToLocalTime().ToString(dateTimeFormat.ShortDatePattern)}_");
            }           
            destination.Append(fileNameWithoutExtension);
            destination.Append(extension);
            return destination.ToString();
        }
    }
}
