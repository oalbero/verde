﻿using LocalizedFileSystemWatcher.Resources;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;

namespace LocalizedFileSystemWatcher
{
    public class Watcher
    {
        private string startDir;
        private string destinationDir;
        private FileSystemWatcher watcher;
        private string filter;
      
        public Watcher(string start, string dest, string filter)
        {
            this.startDir = start;
            this.destinationDir = dest;
            this.filter = filter;
            Setup();            
        }
        public void Setup()
        {
            //string path = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            if (!Directory.Exists(startDir))
            {
                Directory.CreateDirectory(startDir);
            }
            if (!Directory.Exists(destinationDir))
            {
                Directory.CreateDirectory(destinationDir);
            }           
        }
        public void Watch()
        {
            watcher = new FileSystemWatcher(startDir)
            {
                NotifyFilter = NotifyFilters.CreationTime | NotifyFilters.FileName | NotifyFilters.DirectoryName,
                Filter = filter,
                EnableRaisingEvents = true
            };
            watcher.Created += OnCreated;
            watcher.Changed += OnChanged;          
            watcher.Deleted += OnDeleted;
            //watcher.WaitForChanged(WatcherChangeTypes.Created);
            string fileName;

            for (int i = 0; i < 10; i++)
            {
                if (i % 2 == 0)
                {
                    fileName = Path.Combine(startDir, $"{i}.txt");
                    File.Create(fileName);
                    Thread.Sleep(1000);
                    OnCreated(this, new FileSystemEventArgs(WatcherChangeTypes.Created, startDir, $"{i}.txt"));
                }
                else
                {
                    fileName = Path.Combine(startDir, $"{i}.json");
                    File.Create(fileName);
                    Thread.Sleep(1000);
                    OnCreated(this, new FileSystemEventArgs(WatcherChangeTypes.Changed, startDir, $"{i}.json"));                    
                }             
            }            
        }
        private void OnCreated(object sender, FileSystemEventArgs e)
        {
            Console.WriteLine(Messages.FileCreated +  ": " + e.FullPath + " " + e.ChangeType);           
        }
        private void OnChanged(object sender, FileSystemEventArgs e)
        {
            Console.WriteLine(Messages.FileUpdated + ": " + e.FullPath + " " + e.ChangeType);
            if (e.FullPath.Contains(filter))
            {
                File.Move(e.Name, destinationDir);
                Console.WriteLine(Messages.FileMoved + ": " + e.FullPath + destinationDir);
            }
        }
        private void OnDeleted(object sender, FileSystemEventArgs e)
        {
            Console.WriteLine(Messages.FileDeleted + ": " + e.FullPath + " " + e.ChangeType);
        }
    }
}
