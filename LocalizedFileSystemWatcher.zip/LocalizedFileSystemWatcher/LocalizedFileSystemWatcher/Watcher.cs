﻿using LocalizedFileSystemWatcher.Configuration;
using LocalizedFileSystemWatcher.Resources;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace LocalizedFileSystemWatcher
{
    public class Watcher
    {
        private string startDir;        
        private FileSystemWatcher watcher;
        private string filter;
        public bool IsCanceled { get; set; }
        private List<RuleElement> rules;
        private List<DirectoryElement> directories;
       
        public Watcher(List<DirectoryElement> directories, List<RuleElement> rules)
        {
            this.directories = directories;
            this.rules = rules;        
            this.IsCanceled = false;                    
        }
        public void Watch()
        {
            watcher = new FileSystemWatcher()
            {
                NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite | 
                NotifyFilters.CreationTime | NotifyFilters.FileName | NotifyFilters.DirectoryName,                      
                Path = directories.ElementAt(0).DirectoryName,
                IncludeSubdirectories = true,
                EnableRaisingEvents = true
            };
            
            watcher.Created += OnCreated;
            watcher.Changed += OnChanged;

            while (!IsCanceled)
            {
                
            }

            /*Console.WriteLine("Press 'q' to quit the sample.");
            while (Console.Read() != 'q') ;*/
        }
        private void OnCreated(object sender, FileSystemEventArgs e)
        {            
            Console.WriteLine(Messages.FileCreated +  ": " + e.FullPath + " " + e.ChangeType);
            foreach (RuleElement r in rules)
            {
                if (e.FullPath.EndsWith(r.RuleMatch))
                {
                    try
                    {
                        Console.WriteLine(Messages.RuleFound + "  " + r.RuleName);
                        File.Move(e.FullPath, Path.Combine(r.RuleDestination, e.Name));                       
                        Console.WriteLine(e.FullPath + " " + Messages.FileMoved + "--> " + r.RuleDestination);                      
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);                       
                    }
                    break;
                }
                else
                {
                    try
                    {
                        File.Move(e.FullPath, Path.Combine(ConfigParams.DefaultDirectory, e.Name));
                        Console.WriteLine(e.FullPath + " " + Messages.FileMoved + "--> " + ConfigParams.DefaultDirectory);                        
                    }
                    catch (Exception ex)                    
                    {
                        Console.WriteLine(ex.Message);                       
                    }
                    break;
                }
            }
            Console.WriteLine(Environment.NewLine);
        }
        private void OnChanged(object sender, FileSystemEventArgs e)
        {            
            Console.WriteLine(e.FullPath + Messages.FileUpdated + " Change type: "  + e.ChangeType);            
        }      
    }
}
