﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;

namespace LocalizedFileSystemWatcher.Configuration
{
    public static class ConfigParams
    {
        public static List<DirectoryElement> Directories;
        public static List<RuleElement> Rules;
        private static TextWatcherSection section;
        public static CultureInfo Culture;
        public static string DefaultDirectory;
      
        public static void StartConfiguration()
        {
            section = (TextWatcherSection)ConfigurationManager.GetSection("TextWatcher");
            Directories = new List<DirectoryElement>(section.Directories.Count);
            Rules = new List<RuleElement>();

            foreach (DirectoryElement directory in section.Directories)
            {
                Directories.Add (new DirectoryElement
                {
                    DirectoryName = directory.DirectoryName,
                    DirectoryPath = directory.DirectoryPath
                });
            }

            foreach (RuleElement rule in section.Rules)
            {
                Rules.Add(new RuleElement
                {                    
                    Match = rule.Match,
                    Destination = rule.Destination,
                    IsIndexAdded = rule.IsIndexAdded,
                    IsTimeMarked = rule.IsTimeMarked
                });
            }

            CultureInfo.DefaultThreadCurrentCulture = (CultureInfo)section.Culture.CultureInfo;
            CultureInfo.DefaultThreadCurrentUICulture = (CultureInfo)section.Culture.CultureInfo;
            CultureInfo.CurrentUICulture = (CultureInfo)section.Culture.CultureInfo;
            CultureInfo.CurrentCulture = (CultureInfo)section.Culture.CultureInfo;

            Culture = (CultureInfo)section.Culture.CultureInfo;
            DefaultDirectory = section.Default.DirectoryPath;
        }
    }
}
