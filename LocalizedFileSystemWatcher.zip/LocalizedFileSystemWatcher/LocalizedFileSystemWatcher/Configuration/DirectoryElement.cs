﻿using System.Configuration;

namespace LocalizedFileSystemWatcher.Configuration
{
    public class DirectoryElement : ConfigurationElement
    {
        [ConfigurationProperty("name", IsKey = true, IsRequired = true)]
        public string DirectoryName
        {
            get { return (string)base["name"]; }
        }

        [ConfigurationProperty("path", IsRequired = false)]
        //[IntegerValidator(MinValue = 0, MaxValue = 1000000)]
        public string DirectoryPath
        {
            get { return (string)base["path"]; }
            set { this["size"] = value; }
        }
    }
}
