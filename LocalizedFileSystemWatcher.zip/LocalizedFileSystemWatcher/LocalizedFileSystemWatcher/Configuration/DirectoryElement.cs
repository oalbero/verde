﻿using System.Configuration;

namespace LocalizedFileSystemWatcher.Configuration
{
    public class DirectoryElement : ConfigurationElement
    {
        [ConfigurationProperty("name", IsKey = true, IsRequired = true)]
        public string DirectoryName
        {
            get { return (string)base["name"]; }
            set { this["name"] = value; }
        }

        [ConfigurationProperty("path", IsRequired = false)]        
        public string DirectoryPath
        {
            get { return (string)base["path"]; }
            set { this["path"] = value; }
        }
    }
}
