﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalizedFileSystemWatcher.Configuration
{
    public class WorkTimeElement : ConfigurationElement
    {
        [ConfigurationProperty("start")]
        public DateTime StartTime
        {
            get { return (DateTime)this["start"]; }
        }

        [ConfigurationProperty("duration")]
        public TimeSpan Duration
        {
            get { return (TimeSpan)this["duration"]; }
        }       
    }
}
