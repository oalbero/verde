﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;

namespace LocalizedFileSystemWatcher.Configuration
{
    public class RuleElement : ConfigurationElement
    {
        [ConfigurationProperty("ruleName", IsKey = true, IsRequired = true)]
        public string RuleName
        {
            get { return (string)base["ruleName"]; }
            set { this["ruleName"] = value; }
        }

        [ConfigurationProperty("value", IsRequired = false)]
        //[IntegerValidator(MinValue = 0, MaxValue = 1000000)]
        public string RuleValue
        {
            get { return (string)base["value"]; }
            set { this["value"] = value; }
        }
    }
}
