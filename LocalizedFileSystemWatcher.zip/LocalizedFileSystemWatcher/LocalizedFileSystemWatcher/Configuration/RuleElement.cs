﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;

namespace LocalizedFileSystemWatcher.Configuration
{
    public class RuleElement : ConfigurationElement
    {   
        [ConfigurationProperty("match", IsRequired = true)]    
        public string Match
        {
            get { return (string)base["match"]; }
            set { this["match"] = value; }
        }
        [ConfigurationProperty("destination", IsRequired = true)]     
        public string Destination
        {
            get { return (string)base["destination"]; }
            set { this["destination"] = value; }
        }
        [ConfigurationProperty("isIndexed", IsRequired = false)]        
        public bool IsIndexAdded
        {
            get { return (bool)base["isIndexed"]; }
            set { this["isIndexed"] = value; }
        }
        [ConfigurationProperty("isTimeMarked", IsRequired = false)]        
        public bool IsTimeMarked
        {
            get { return (bool)base["isTimeMarked"]; }
            set { this["isTimeMarked"] = value; }
        }
    }
}
