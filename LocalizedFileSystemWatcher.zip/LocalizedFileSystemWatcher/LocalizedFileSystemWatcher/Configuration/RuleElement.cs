﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;

namespace LocalizedFileSystemWatcher.Configuration
{
    public class RuleElement : ConfigurationElement
    {        
        [ConfigurationProperty("name", IsKey = true, IsRequired = true)]
        public string RuleName
        {
            get { return (string)base["name"]; }
            set { this["name"] = value; }
        }
        [ConfigurationProperty("match", IsRequired = true)]    
        public string RuleMatch
        {
            get { return (string)base["match"]; }
            set { this["match"] = value; }
        }
        [ConfigurationProperty("destination", IsRequired = true)]     
        public string RuleDestination
        {
            get { return (string)base["destination"]; }
            set { this["destination"] = value; }
        }
        [ConfigurationProperty("isIndexed", IsRequired = false)]        
        public string RuleIsIndexed
        {
            get { return (string)base["isIndexed"]; }
            set { this["isIndexed"] = value; }
        }
        [ConfigurationProperty("isTimeMarked", IsRequired = false)]        
        public string RuleIsTimeMarked
        {
            get { return (string)base["isTimeMarked"]; }
            set { this["isTimeMarked"] = value; }
        }
    }
}
