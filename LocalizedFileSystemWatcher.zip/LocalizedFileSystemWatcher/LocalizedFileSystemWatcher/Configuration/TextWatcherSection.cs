﻿using System;
using System.Configuration;

namespace LocalizedFileSystemWatcher.Configuration
{
    public class TextWatcherSection : ConfigurationSection
    {
        [ConfigurationProperty("appName")]
        public string ApplicationName
        {
            get { return (string)base["appName"]; }
        }
        [ConfigurationProperty("culture")]
        public CultureElement Culture
        {
            get { return (CultureElement)this["culture"]; }
        }
        [ConfigurationProperty("defaultDirectory")]
        public DirectoryElement Default
        {
            get { return (DirectoryElement)this["defaultDirectory"]; }
        }
        [ConfigurationCollection(typeof(DirectoryElement),
            AddItemName = "directory",
            ClearItemsName = "clear",
            RemoveItemName = "del")]
        [ConfigurationProperty("directories")]
        public DirectoryElementCollection Directories
        {
            get { return (DirectoryElementCollection)this["directories"]; }
        }
        
        [ConfigurationCollection(typeof(RuleElement),
            AddItemName = "rule",
            ClearItemsName = "clear",
            RemoveItemName = "del")]
        [ConfigurationProperty("rules")]
        public RuleElementCollection Rules
        {
            get { return (RuleElementCollection)this["rules"]; }
        }       
    }
}
