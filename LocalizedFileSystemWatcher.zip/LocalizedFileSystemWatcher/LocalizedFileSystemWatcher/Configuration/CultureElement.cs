﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Text;

namespace LocalizedFileSystemWatcher.Configuration
{
    public class CultureElement :ConfigurationElement
    {
        [ConfigurationProperty("cultureInfo")]
        public CultureInfo CultureInfo
        {
            get { return (CultureInfo)this["cultureInfo"]; }
        }
    }
}
