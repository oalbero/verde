﻿using LocalizedFileSystemWatcher.Configuration;
using LocalizedFileSystemWatcher.Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Threading;

namespace LocalizedFileSystemWatcher
{
    class Program
    {
        static void Main(string[] args)
        {
            ConfigParams.StartConfiguration();
            Console.WriteLine(Messages.CurrentCulture + ConfigParams.Culture);
            Console.WriteLine(Messages.CancelMessage);
           
            Watcher watcher = new Watcher(ConfigParams.Directories, ConfigParams.Rules);

            Console.CancelKeyPress += (o, e) =>
            {
                watcher.IsCanceled = true;
            };           
            watcher.Watch(); 
        }
    }
}
