﻿using LocalizedFileSystemWatcher.Configuration;
using LocalizedFileSystemWatcher.Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Threading;

namespace LocalizedFileSystemWatcher
{
    class Program
    {
        static void Main(string[] args)
        {
            ConfigParams.StartConfiguration();
            Console.WriteLine(Messages.CurrentCulture + ConfigParams.Culture);
            Console.WriteLine(Messages.CancelMessage);
            Console.WriteLine(Messages.Duration + ConfigParams.WorkTime.TotalSeconds);
            Watcher watcher = new Watcher(ConfigParams.Directories[0], ConfigParams.Rules[3].RuleValue, ConfigParams.Rules[0].RuleValue);

            CancellationTokenSource source = new CancellationTokenSource(ConfigParams.WorkTime);
            watcher.Watch();

            Console.CancelKeyPress += (o, e) =>
            {                
                source.Cancel();
            };          
        }
    }
}
