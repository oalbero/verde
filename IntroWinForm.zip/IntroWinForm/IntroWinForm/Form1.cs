﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TimeHelper;

namespace IntroWinForm
{
    public partial class form1 : Form
    {
        public form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            var name = txtName.Text;
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Please provide your name!", "Attention please!", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show($"{Clocker.MakeHelloAtTime(name)}", "Great", MessageBoxButtons.OK);
            }
        }
    }
}
