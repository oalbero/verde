﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MongoDb_task
{
    class Program
    {
        static List<Book> bookList;

        public static List<Book> GetBooks()
        {
            bookList = new List<Book>();
            bookList.Add(new Book { Name = "Hobbit", Author = "Tolkien", Count = 5, Genre = new string[] { "fantasy" }, Year = 2014 });
            bookList.Add(new Book { Name = "Lord of the Rings", Author = "Tolkien", Count = 3, Genre = new string[] { "fantasy" }, Year = 2015 });
            bookList.Add(new Book { Name = "Kolobok",  Count = 10, Genre = new string[] { "kids" }, Year = 2000 });
            bookList.Add(new Book { Name = "Repka", Count = 1, Genre = new string[] { "kids" }, Year = 2000 });
            bookList.Add(new Book { Name = "Ulysses", Author = "Joyce", Count = 3, Genre = new string[] { "kids" }, Year = 2001 });
            
            return bookList;
        }

        static void Main(string[] args)
        {
            var connectionString = "mongodb://localhost:27017";
            var client = new MongoClient(connectionString);
            IMongoDatabase db = client.GetDatabase("BookStore");

            Console.WriteLine("Press a key do see every next step result\n");

            // Task 1 
            // Добавьте  книги
            var collection = db.GetCollection<Book>("books");
            collection.InsertMany(GetBooks());
            Console.WriteLine("Existing databases: ");
            using (var cursor = client.ListDatabases())
            {
                var databaseDocuments = cursor.ToList();
                foreach (var dbr in databaseDocuments)
                {
                    Console.WriteLine(dbr["name"].ToString());
                }
            }
            
            Console.Read();

            // Get inserted book from db
            IMongoCollection<Book> _books = db.GetCollection<Book>("books");
            var justInsertedBooks = _books.Find(Builders<Book>.Filter.Empty).
                Project<Book>(Builders<Book>.Projection.Include(b => b.Name).Include(b => b.Author).
                Include(b => b.Genre).Include(b=>b.Count))
                .ToList().AsQueryable();

            Console.WriteLine("\nJust inserted books...");
            foreach (var b in justInsertedBooks)
            {
                Console.WriteLine($"Name: {b.Name}, author: {b.Author}, count: {b.Count}, genre: {b.Genre[0]}");
            }
            Console.Read();
            // Task 2a 
            // Покажите в результате только название книги

            var condition_2a = Builders<Book>.Filter.Gt(b => b.Count, 1);
            var fields_2a = Builders<Book>.Projection.Include(b => b.Name);
            var results_2a = _books.Find(condition_2a).Project<Book>(fields_2a).ToList().AsQueryable();
            Console.WriteLine("\nTyping book names with count more than 1");
            foreach (var r in results_2a)
            {
                Console.WriteLine(r.Name);
            }
            Console.Read();
            // Task 2b
            // Отсортируйте книги по названию
            var results_2b = _books.Find(condition_2a).Project<Book>(fields_2a).SortBy(b => b.Name).ToList().AsQueryable();
            Console.WriteLine("\nSorted books by name");
            foreach (var r in results_2b)
            {
                Console.WriteLine(r.Name);
            }
            Console.Read();
            // Task 2c 
            // Ограничьте количество возвращаемых книг тремя.           
            var results_2c = _books.Find(condition_2a).Project<Book>(fields_2a).Limit(3).ToList().AsQueryable();
            Console.WriteLine("\nFirst 3 books in list");
            foreach (var r in results_2c)
            {
                Console.WriteLine(r.Name);
            }
            Console.Read();
            // Task 2d 
            // Подсчитайте количество таких книг.
            var results_2d = _books.Find(condition_2a).Project<Book>(fields_2a).ToList().AsQueryable().Count();
            Console.WriteLine($"\nCount of books with more than one example: {results_2d}");
            Console.Read();
            // Task 3
            // Найдите книгу с макимальным/минимальным количеством (count).
            var result3 = _books.Find(FilterDefinition<Book>.Empty).SortByDescending(b => b.Count).Limit(1); // Sort
            Console.WriteLine($"\nBook with max count: {result3.FirstOrDefault().Name}, count: {result3.FirstOrDefault().Count}");
            Console.Read();
            // Task 4 
            // Найдите список авторов (каждый автор должен быть в списке один раз).
            var result4 = _books.Find(Builders<Book>.Filter.Exists(b => b.Author)).
                Project<Book>(Builders<Book>.Projection.Include(b => b.Author)).
                ToList().AsQueryable().Select(b => b.Author).Distinct().ToList().AsQueryable();
            Console.WriteLine("\nDistinct Authors");
            foreach (var r in result4)
            {
                Console.WriteLine(r);
            }
            Console.Read();
            // Task 5 
            // Выберите книги без авторов.
            var result5 = _books.Find(Builders<Book>.Filter.Not(Builders<Book>.Filter.Exists(b => b.Author))).
                Project<Book>(Builders<Book>.Projection.Include(b => b.Name)).
                ToList().AsQueryable();
            Console.WriteLine("\nBooks without Authors");
            foreach (var r in result5)
            {
                // SIR list is empty why?
                Console.WriteLine(r.Name);
            }
            Console.Read();
            // Task 6 
            // Увеличьте количество экземпляров каждой книги на единицу.            
            _books.UpdateMany(
                                Builders<Book>.Filter.Empty,
                                Builders<Book>.Update.Inc("Count", 1));
            // get Updated collection
            _books = db.GetCollection<Book>("books");

            var updateCountResult = _books.Find(Builders<Book>.Filter.Empty).
                Project<Book>(Builders<Book>.Projection.Include(b => b.Name).Include(b => b.Count)).
                ToList().AsQueryable();
            Console.WriteLine("\nCount updated with +1 and now is...");
            foreach (var r in updateCountResult)
            {
                Console.WriteLine($"Book: {r.Name}, count: {r.Count}");
            }
            Console.Read();
            // Task 7
            // Добавьте дополнительный жанр “favority” всем книгам с жанром “fantasy” 
            // (последующие запуски запроса не должны дублировать жанр “favority”).          
            var filterForFantasy = Builders<Book>.Filter.Eq(e => e.Genre.ElementAt(0), "fantasy");
            var updateForFantasy = Builders<Book>.Update
                    .Push<String>(e => e.Genre, "favorite");
            _books.UpdateMany(filterForFantasy, updateForFantasy);
            var updateGenreResult = _books.Find(Builders<Book>.Filter.Empty).
               Project<Book>(Builders<Book>.Projection.Include(b => b.Name).Include(b => b.Genre)).
               ToList().AsQueryable();
            Console.WriteLine("\nAfter updating genre...");
            foreach (var r in updateCountResult)
            {
                // SIR throws exception why?
                //Console.WriteLine($"Book: {r.Name}, genre: {r.Genre[0]}");
            }
            Console.Read();
            // Task 8
            // Удалите книги с количеством экземпляров меньше трех.
            var deleteCountLt3 = _books.DeleteMany(Builders<Book>.Filter.Lt("Count", 3));

            var afterDeletedFilter = Builders<Book>.Filter.Empty;
            var afterDeletedCondition = Builders<Book>.Projection.Include(b => b.Name).Include(b => b.Count);
            var afterDeletedResult = _books.Find(afterDeletedFilter).Project<Book>(afterDeletedCondition).ToList().AsQueryable();
            Console.WriteLine("\nAfter deleting fbooks with count > 3 books are...");
            foreach (var r in afterDeletedResult)
            {
                Console.WriteLine($"Book: {r.Name}, Count: {r.Count}");
            }
            Console.Read();
            // Task 9
            // Удалите все книги
            collection.DeleteMany(FilterDefinition<Book>.Empty);
            var afterDeletedAllResult = _books.Find(afterDeletedFilter).Project<Book>(afterDeletedCondition).ToList().Count;

            Console.WriteLine($"\nAfter deleting all books count is: {afterDeletedAllResult}");
            Console.Read();
        }
    }
}
