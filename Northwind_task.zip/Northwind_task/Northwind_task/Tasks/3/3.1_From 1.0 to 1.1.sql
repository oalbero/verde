﻿USE [Northwind_task_1.0]
GO

/****** Object:  Table [dbo].[CreditCards]    Script Date: 09/10/2019 19:15:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CreditCards](
	[CardId] [tinyint] NOT NULL,
	[CardNumber] [nchar](10) NOT NULL,
	[ValidationDate] [datetime] NOT NULL,
	[CardHolderName] [nchar](10) NULL,
	[EmployeeId] [int] NOT NULL,
 CONSTRAINT [PK_CreditCards] PRIMARY KEY CLUSTERED 
(
	[CardId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CreditCards]  WITH CHECK ADD  CONSTRAINT [FK_CreditCards_Employees] FOREIGN KEY([EmployeeId])
REFERENCES [dbo].[Employees] ([EmployeeID])
GO

ALTER TABLE [dbo].[CreditCards] CHECK CONSTRAINT [FK_CreditCards_Employees]
GO


