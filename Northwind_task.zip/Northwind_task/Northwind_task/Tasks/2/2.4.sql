﻿-- 1.	Выдать всех поставщиков (колонка CompanyName в таблице Suppliers), у которых нет хотя бы одного 
-- продукта на складе (UnitsInStock в таблице Products равно 0). Использовать вложенный SELECT для этого
-- запроса с использованием оператора IN. 
select CompanyName from Suppliers
where SupplierID in (select SupplierID from Products where Products.UnitsInStock = 0);

-- Выдать всех продавцов, которые имеют более 150 заказов. Использовать вложенный SELECT.
select EmployeeID from Employees where 
(select COUNT(OrderID) from Orders where Orders.EmployeeID = Employees.EmployeeID) > 150;

-- 3.	Выдать всех заказчиков (таблица Customers), которые не имеют ни одного заказа 
-- (подзапрос по таблице Orders). Использовать оператор EXISTS.
select CustomerID from Customers 
where not exists (select OrderId from Orders where Orders.CustomerID = Customers.CustomerID);