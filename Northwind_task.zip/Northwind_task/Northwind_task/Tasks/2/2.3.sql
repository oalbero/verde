﻿-- 1.	Определить продавцов, которые обслуживают регион 'Western' (таблица Region). 
select distinct e.EmployeeID, e.FirstName
from Employees e
inner join  EmployeeTerritories on e.EmployeeID = EmployeeTerritories.EmployeeID
inner join Territories on EmployeeTerritories.TerritoryID = Territories.TerritoryID
inner join Region on Region.RegionID = Territories.RegionID
where Region.RegionDescription = 'Western';

-- 2.	Выдать в результатах запроса имена всех заказчиков из таблицы Customers 
-- и суммарное количество их заказов из таблицы Orders. Принять во внимание, что у некоторых заказчиков 
-- нет заказов, но они также должны быть выведены в результатах запроса. Упорядочить результаты 
-- запроса по возрастанию количества заказов.
select c.ContactName, c.CustomerID, 
(select count(o.OrderID) from Orders o where o.CustomerID=c.CustomerID) as OrderCount
from Customers c
order by OrderCount;