﻿-- 1.	Выбрать все заказы (OrderID) из таблицы Order Details (заказы не должны повторяться), 
-- где встречаются продукты с количеством от 3 до 10 включительно – это колонка Quantity 
-- в таблице Order Details. Использовать оператор BETWEEN. Запрос должен возвращать только колонку OrderID.

select distinct(OrderID) from  dbo.[Order Details]
where Quantity Between  3 and 10;

-- 2.	Выбрать всех заказчиков из таблицы Customers, у которых название страны начинается 
-- на буквы из диапазона b и g. Использовать оператор BETWEEN. Проверить, что в результаты 
-- запроса попадает Germany. Запрос должен возвращать только колонки CustomerID и Country и отсортирован по Country.

Select CustomerID, Country 
from Customers
where Country between 'b%' and 'h%'
order by Country;

-- 3.	Выбрать всех заказчиков из таблицы Customers, у которых название страны начинается 
-- на буквы из диапазона b и g, не используя оператор BETWEEN. 

Select CustomerID, Country 
from Customers
where substring(Country, 1, 1) in ('b', 'c', 'd', 'e', 'f', 'g')
order by Country;