﻿CREATE TABLE [dbo].[CreditCards] (
    [CardId]         TINYINT    NOT NULL,
    [CardNumber]     NCHAR (10) NOT NULL,
    [ValidationDate] DATETIME   NOT NULL,
    [CardHolderName] NCHAR (10) NULL,
    [EmployeeId]     INT        NOT NULL,
    CONSTRAINT [PK_CreditCards] PRIMARY KEY CLUSTERED ([CardId] ASC),
    CONSTRAINT [FK_CreditCards_Employees] FOREIGN KEY ([EmployeeId]) REFERENCES [dbo].[Employees] ([EmployeeID])
);

