﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;

namespace HttpDownloadLib
{
    public class DownloadWorker
    {
        public EventHandler<string> Log;
        public event FileFoundEventHandler FileFound;
        public delegate void FileFoundEventHandler(Object sender, FileFoundEventArgs args);

        private int MaxDeepLevel;
        private DirectoryInfo rootDirectory;
        private readonly ISet<Uri> visitedUrls = new HashSet<Uri>();
        private const string HtmlDocumentMediaType = "text/html";
        private List<string> allowedFileTypes;
        private string allowedDomain;
        private string startUrl;
        public DownloadWorker(DirectoryInfo rootDirectory, string startUrl)
        {            
            this.startUrl = startUrl;
            this.rootDirectory = rootDirectory;
            MaxDeepLevel = int.Parse(ConfigurationManager.AppSettings["deepLevel"]);
            allowedDomain = ConfigurationManager.AppSettings["allowedDomain"];            
            allowedFileTypes = ConfigurationManager.AppSettings["allowedFileTypes"].Split(',').Select(t => t.Trim()).ToList();

            Console.WriteLine($"START: {startUrl}\n");
        }       
        public void ScanWebsite()
        {
            visitedUrls.Clear();
            using (var httpClient = new HttpClient())
            {
                httpClient.BaseAddress = new Uri(startUrl);
                ScanUrl(httpClient, httpClient.BaseAddress, 0);
            }
        }
        private void ScanUrl(HttpClient httpClient, Uri uri, int level)
        {            
            if (level > MaxDeepLevel || visitedUrls.Contains(uri) || !IsValidScheme(uri.Scheme))
            {
                return;
            }
            visitedUrls.Add(uri);
            HttpResponseMessage head = httpClient.SendAsync(new HttpRequestMessage(HttpMethod.Head, uri)).Result;

            if (!head.IsSuccessStatusCode)
            {
                return;
            }
            if (head.Content.Headers.ContentType?.MediaType == HtmlDocumentMediaType)
            {
                ProcessHtmlDocument(httpClient, uri, level);
            }
            else
            {
                ProcessFile(httpClient, uri);
            }
        }
        private void ProcessFile(HttpClient httpClient, Uri uri)
        {
            OnLogProcess($"*  File found: {uri}");
            if (!IsAcceptableFile(uri, allowedFileTypes))
            {
                OnLogProcess($"   - File type is not allowed to save.");
                return;
            }
            var response = httpClient.GetAsync(uri).Result;
            
            SaveFile(uri, response.Content.ReadAsStreamAsync().Result);
            //OnFileFound(new FileFoundEventArgs(uri, response.Content.ReadAsStreamAsync().Result));
            
            OnLogProcess($"  + File saved.");
        }
        private void ProcessHtmlDocument(HttpClient httpClient, Uri uri, int level)
        {
            OnLogProcess($"*  Html found: {uri}");            
            var response = httpClient.GetAsync(uri).Result;
            var document = new HtmlDocument();
            document.Load(response.Content.ReadAsStreamAsync().Result, Encoding.UTF8);            
            SaveHtmlDocument(uri, GetDocumentFileName(document), GetDocumentStream(document));
            OnLogProcess($"  + Html saved.");
            
            var attributesWithLinks = document.DocumentNode.Descendants().SelectMany(d => d.Attributes.Where(IsAttributeWithLink));
            foreach (var attributesWithLink in attributesWithLinks)
            {
                Uri currentUri = new Uri(httpClient.BaseAddress, attributesWithLink.Value);
                ScanUrlForRequiredDomain(httpClient, level, currentUri);                
            }
        }
        private void ScanUrlForRequiredDomain(HttpClient httpClient, int level, Uri currentUri)
        {
            if (allowedDomain == "currentDomain")
            {
                string domainOfCurrentLink = GetDomain(currentUri);
                string startDomain = GetDomain(new Uri(startUrl));                
                if (!domainOfCurrentLink.Equals(startDomain))
                {
                    OnLogProcess($"-- SKIPPED-NOT IN CURRENT DOMAIN -- {currentUri}");
                }
                else
                {
                    ScanUrl(httpClient, currentUri, level + 1);
                }
            }
            else if (allowedDomain == "subDomain")
            {
                if (!IsSubDomainOfStartUri(currentUri))
                {
                    OnLogProcess($"-- SKIPPED-NOT SUBDOMAIN -- {currentUri}");
                }
                else
                {
                    ScanUrl(httpClient, currentUri, level + 1);
                }
            }
            else if(allowedDomain == "allDomains") 
            {
                ScanUrl(httpClient, currentUri, level + 1);
            }
        }
        private static string GetDomain(Uri uri)
        {
            var nodes = uri.Host.Split('.');
            var lastNodeIndex = nodes.Length - 1;
            if (lastNodeIndex > 0)
            {
                return nodes[lastNodeIndex - 1];
            }
            else
                return string.Empty;
        }
        private bool IsSubDomainOfStartUri(Uri uri)
        {
            string startDomain = GetDomain(new Uri(startUrl));
            if (uri.Host.Split('.').Length > 1)
            {
                if (uri.Host.Contains(startDomain))
                {
                    return true;
                }
            }
            return false;
        }        
        private string GetDocumentFileName(HtmlDocument document)
        {
            return document.DocumentNode.Descendants("title").FirstOrDefault()?.InnerText + ".html";
        }
        private Stream GetDocumentStream(HtmlDocument document)
        {
            MemoryStream memoryStream = new MemoryStream();
            document.Save(memoryStream);
            memoryStream.Seek(0, SeekOrigin.Begin);
            return memoryStream;
        }
        private bool IsValidScheme(string scheme)
        {
            switch (scheme)
            {
                case "http":
                case "https":
                    return true;
                default:
                    return false;
            }
        }
        private bool IsAttributeWithLink(HtmlAttribute attribute)
        {
            return attribute.Name == "src" || attribute.Name == "href";
        }
        private void SaveToFile(Stream stream, string fileFullPath)
        {
            var fileStream = File.Create(fileFullPath);
            stream.CopyTo(fileStream);
            fileStream.Close();
        }
        private void SaveHtmlDocument(Uri uri, string name, Stream documentStream)
        {
            string directoryPath = CombineLocations(rootDirectory, uri);
            Directory.CreateDirectory(directoryPath);
            name = RemoveInvalidSymbols(name);
            string fileFullPath = Path.Combine(directoryPath, name);

            SaveToFile(documentStream, fileFullPath);
            documentStream.Close();
        }
        private void SaveFile(Uri uri, Stream fileStream)
        {
            string fileFullPath = CombineLocations(rootDirectory, uri);
            var directoryPath = Path.GetDirectoryName(fileFullPath);
            Directory.CreateDirectory(directoryPath);
            if (Directory.Exists(fileFullPath))
            {
                fileFullPath = Path.Combine(fileFullPath, Guid.NewGuid().ToString());
            }
            SaveToFile(fileStream, fileFullPath);
            fileStream.Close();
        }
        private string CombineLocations(DirectoryInfo directory, Uri uri)
        {
            return Path.Combine(directory.FullName, uri.Host) + uri.LocalPath.Replace("/", @"\");
        }
        private string RemoveInvalidSymbols(string filename)
        {
            var invalidSymbols = Path.GetInvalidFileNameChars();
            return new string(filename.Where(c => !invalidSymbols.Contains(c)).ToArray());
        }
        private bool IsAcceptableFile(Uri uri, List<string> fileTypes)
        {
            return fileTypes.Any(c => uri.Segments.Last().EndsWith(c));
        }
        private void OnLogProcess(string args)
        {
            InvokeLogEvent(Log, args);
        }
        private void InvokeLogEvent<T>(EventHandler<T> logEvent, T args)
        {
            if (logEvent != null)
            {
                logEvent.Invoke(this, args);
            }
        }
        private void OnFileFound(FileFoundEventArgs args)
        {
            FileFound?.Invoke(this, args);
        }       
    }
    public class FileFoundEventArgs : EventArgs
    {
        public Uri uri;
        public Stream stream;
        public FileFoundEventArgs(Uri uri, Stream stream)
        {
            this.uri = uri;
            this.stream = stream;
        }
    }
}