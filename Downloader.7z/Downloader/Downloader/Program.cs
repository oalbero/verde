﻿using HttpDownloadLib;
using System;
using System.IO;

namespace Downloader
{
    class Program
    {
        static void Main(string[] args)
        {            
            DirectoryInfo rootDirectory = new DirectoryInfo("c:\\google");
            string startUrl = "https://google.am/";

            DownloadWorker downloader = new DownloadWorker(rootDirectory, startUrl);            
            downloader.Log += OnLog;
            try
            {               
                downloader.ScanWebsite();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error during site downloading: {ex.Message}");
            }
        }
        private static void OnLog(object sender, string e)
        {
            Console.WriteLine(e);
        }
    }
}
