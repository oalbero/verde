﻿using HttpDownloadLib;
using System;
using System.IO;

namespace Downloader
{
    class Program
    {
        static void Main(string[] args)
        {            
            DirectoryInfo rootDirectory = new DirectoryInfo("c:\\google");
            string startUrl = "https://www.google.am/";

            DownloadWorker downloader = new DownloadWorker(rootDirectory, startUrl);            
            downloader.Log += OnLog;
            //downloader.FileFound += OnFileFound;
            try
            {               
                downloader.ScanWebsite();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error during site downloading: {ex.Message}");
            }
        }
        private static void OnLog(object sender, string e)
        {
            Console.WriteLine(e);
        }
        private static void OnFileFound(object sender, FileFoundEventArgs args)
        {
            Console.WriteLine($"Found file: {args.uri}. Save or move to db?");            
            // Move
            // Save db
        }
    }
}
