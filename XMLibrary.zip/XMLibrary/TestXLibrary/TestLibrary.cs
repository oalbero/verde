using NUnit.Framework;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using TestXLibrary;
using XMLibrary;
using XMLibrary.Entities;
using XMLibrary.Readers;
using XMLibrary.Writers;

namespace Tests
{
    public class Tests
    {
        XLibrarian lib;
        [SetUp]
        public void Setup()
        {
            lib = new XLibrarian();
            lib.AddReaders(new BookReader(), new NewspaperReader(), new PatentReader());
            lib.AddWriters(new BookWriter(), new NewspaperWriter(), new PatentWriter());
        }
        [Test]
        public void TestBookReader()
        {
            TextReader bookData = new StringReader(@"<?xml version='1.0' encoding='utf-16'?>" +
                                             "<library>" + Data.Book1AsXml+ "</library>");
            Book book = lib.ReadBook(bookData) as Book;
            
            Assert.True(book.Title == Data.Book1.Title &&
                book.Authors.First().FirstName == Data.Book1.Authors.First().FirstName &&
                book.Authors.First().LastName == Data.Book1.Authors.First().LastName &&
                book.ISBN == Data.Book1.ISBN &&
                book.PageCount == Data.Book1.PageCount &&
                book.PublicationName == Data.Book1.PublicationName &&
                book.PublicationPlace == Data.Book1.PublicationPlace &&
                book.PublicationYear == Data.Book1.PublicationYear &&
                book.Annotation == Data.Book1.Annotation);
        }
        [Test]
        public void TestBookWriter()
        {
            StringBuilder actualResult = new StringBuilder();
            StringWriter sw = new StringWriter(actualResult);

            string expectedResult = @"<?xml version=""1.0"" encoding=""utf-16""?>" +
                "<library>" + Data.Book1AsXml + "</library>";

            lib.WriteBook(sw, Data.Book1);
            sw.Dispose();
            Assert.AreEqual(expectedResult, actualResult.ToString());
        }
        [Test]
        public void TestWrongBookWriter()
        {
            StringBuilder actualResult = new StringBuilder();
            StringWriter sw = new StringWriter(actualResult);

            string expectedResult = @"<?xml version=""1.0"" encoding=""utf-16""?>" +
                "<library>" + Data.BookWrongAsXml + "</library>";

            lib.WriteBook(sw, Data.Book1);
            sw.Dispose();
            Assert.AreNotEqual(expectedResult, actualResult.ToString());
        }
        [Test]
        public void TestAllReaders()
        {
            TextReader libData = new StringReader(@"<?xml version=""1.0"" encoding=""utf-16""?>" +
                                             "<library>" +
                                                Data.Book1AsXml +
                                                Data.Newspaper1AsXml +
                                                Data.Patent1AsXml +
                                             "</library>");

            List<IEntity> entities = new List<IEntity>();
            foreach (IEntity e in lib.ReadAllEntities(libData))
            {
                entities.Add(e);
            }            
            libData.Dispose();
            
            Book book = entities[0] as Book;
            Newspaper newspaper = entities[1] as Newspaper;
            Patent patent = entities[2] as Patent;

            Assert.True(
                book.Title == Data.Book1.Title &&
                book.Authors.First().FirstName == Data.Book1.Authors.First().FirstName &&
                book.Authors.First().LastName == Data.Book1.Authors.First().LastName &&
                book.ISBN == Data.Book1.ISBN &&
                book.PageCount == Data.Book1.PageCount &&
                book.PublicationName == Data.Book1.PublicationName &&
                book.PublicationPlace == Data.Book1.PublicationPlace &&
                book.PublicationYear == Data.Book1.PublicationYear &&
                book.Annotation == Data.Book1.Annotation);

            Assert.True(
                newspaper.Title == Data.Newspaper1.Title &&
                newspaper.PublicationDate == Data.Newspaper1.PublicationDate &&
                newspaper.PublicationName == Data.Newspaper1.PublicationName &&
                newspaper.PublicationPlace == Data.Newspaper1.PublicationPlace &&
                newspaper.Number == Data.Newspaper1.Number &&
                newspaper.PageCount == Data.Newspaper1.PageCount &&
                newspaper.ISSN == Data.Newspaper1.ISSN &&
                newspaper.Annotation == Data.Newspaper1.Annotation);

            Assert.True(
                patent.Title == Data.Patent1.Title &&
                patent.Authors.First().FirstName == Data.Patent1.Authors.First().FirstName &&
                patent.Authors.First().LastName == Data.Patent1.Authors.First().LastName &&
                patent.Authors.Last().FirstName == Data.Patent1.Authors.Last().FirstName &&
                patent.Authors.Last().LastName == Data.Patent1.Authors.Last().LastName &&
                patent.Country == Data.Patent1.Country &&
                patent.IssueDate == Data.Patent1.IssueDate &&
                patent.RegistrationDate == Data.Patent1.RegistrationDate &&
                patent.RegistrationNumber == Data.Patent1.RegistrationNumber &&
                patent.Annotation == Data.Patent1.Annotation);
        }
        [Test]
        public void TestAllWriters()
        {
            /*
            string fileName = "book1.xml";
            
            var book = new XElement("library",
                new XElement("book",
                    new XAttribute("publicationPlace", Data.Book1.PublicationPlace),
                    new XAttribute("publicationName", Data.Book1.PublicationName),
                    new XAttribute("publicationYear", Data.Book1.PublicationYear),
                    new XAttribute("ISBN", Data.Book1.ISBN),
                    new XElement("title", Data.Book1.Title),
                    new XElement("authors", 
                        new XElement("author", 
                            new XAttribute("firstName", Data.Book1.Authors.First().FirstName)),
                            new XAttribute("lastName", Data.Book1.Authors.First().LastName)),
                    new XElement("pageCount", Data.Book1.PageCount),
                    new XElement("annotation", Data.Book1.Annotation)));
            lib.WriteToFile(book, fileName);
            
            string writtenBook = lib.ReadFromFile(fileName);
            Assert.AreEqual(Data.Book1AsXml, writtenBook);
            */
            StringBuilder actualResult = new StringBuilder();
            StringWriter sw = new StringWriter(actualResult);
            
            var entities = new IEntity[]
            {
                Data.Book1,
                Data.Newspaper1,
                Data.Patent1
            };
            string expectedResult = @"<?xml version=""1.0"" encoding=""utf-16""?>" +
                "<library>" +
                    Data.Book1AsXml +
                    Data.Newspaper1AsXml +
                    Data.Patent1AsXml +
                "</library>";
            lib.WriteAllEntities(sw, entities);
            sw.Dispose();
            Assert.AreEqual(expectedResult, actualResult.ToString());
        }
    }
}