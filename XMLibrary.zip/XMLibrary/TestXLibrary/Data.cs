﻿using System;
using System.Collections.Generic;
using System.Text;
using XMLibrary.Entities;

namespace TestXLibrary
{
    public static class Data
    {
        public static Book Book1
        {
            get
            {
                return new Book
                {
                    Title = "The Dispossessed",
                    Authors = new List<Author>
                    {
                        new Author{ FirstName = "Ursula", LastName="Le Guine"}
                    },
                    PublicationPlace = "Oregon",
                    PublicationName = "Hugo",
                    PublicationYear = 1964,
                    PageCount = 303,
                    Annotation = "You are the best",
                    ISBN = "1155-8888-9966"
                };
            }
        }
        public static string Book1AsXml
        {
            get
            {
                return "<book publicationPlace=\"Oregon\" publicationName=\"Hugo\" publicationYear=\"1964\" isbn=\"1155-8888-9966\">" +
                            "<title>The Dispossessed</title>" +
                             "<authors><author firstName=\"Ursula\" lastName=\"Le Guine\" /></authors>" +
                             "<pageCount>303</pageCount>" +
                             "<annotation>You are the best</annotation>"+
                        "</book>";
            }
        }
        public static string BookWrongAsXml
        {
            get
            {
                return "<book publicationPlace=\"Oregon\" publicationName=\"Hugo\" publicationYear=\"1964\" isbn=\"1155-8888-9966\">" +
                            "<name>The Dispossessed</name>" +
                             "<authors><author firstName=\"Ursula\" lastName=\"Le Guine\" /></authors>" +
                             "<pageCount>303</pageCount>" +
                             "<annotation>You are the best</annotation>" +
                        "</book>";
            }
        }
        public static Newspaper Newspaper1
        {
            get
            {
                return new Newspaper
                {
                    Title = "The Times",
                    PublicationPlace = "New York",
                    PublicationName = "City",
                    PageCount = 101,
                    Annotation = "Magazine magazine",
                    Number = 12,
                    PublicationDate = new DateTime(2013, 11, 12),
                    ISSN = "1155-9999-9966"
                };
            }
        }
        public static string Newspaper1AsXml
        {
            get
            {
                return "<newspaper publicationPlace=\"New York\" publicationName=\"City\" publicationDate=\"12/11/2013\" issn=\"1155-9999-9966\" number=\"12\">"+
                            "<title>The Times</title>"+                               
                            "<pageCount>101</pageCount>"+
                            "<annotation>Magazine magazine</annotation>"+
                        "</newspaper>";
            }
        }
        public static Patent Patent1
        {
            get
            {
                return new Patent
                {
                    Title = "TV",
                    Authors = new List<Author>
                    {
                        new Author{ FirstName = "Hovhannes", LastName="Adamyan"},
                        new Author{ FirstName="Karo", LastName="Halabyan"}
                    },
                    Country="Planet",
                    RegistrationNumber = "1587-OO",
                    RegistrationDate = new DateTime(2014, 10, 12),
                    IssueDate = new DateTime(2015, 2, 1),
                    PageCount = 99, 
                    Annotation="Hi tv"
                };
            }
        }
        public static string Patent1AsXml
        {
            get
            {
                return "<patent country=\"Planet\" registrationNumber=\"1587-OO\" registrationDate=\"12/10/2014\" issueDate=\"01/02/2015\">"+
                            "<title>TV</title>"+
                            "<authors><author firstName=\"Hovhannes\" lastName=\"Adamyan\" />"+
                            "<author firstName=\"Karo\" lastName=\"Halabyan\" /></authors>"+
                            "<pageCount>99</pageCount>"+
                            "<annotation>Hi tv</annotation>"+
                         "</patent>";
            }
        }
    }
}