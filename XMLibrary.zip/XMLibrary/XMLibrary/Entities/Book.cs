﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XMLibrary.Entities
{
    public class Book : IEntity
    {
        // Mandatory
        public string Title { get; set; }
        public List<Author> Authors { get; set; }
        public string PublicationPlace { get; set; }
        public string PublicationName { get; set; }
        // Mandatory
        public int PublicationYear { get; set; }
        public int PageCount { get; set; }
        public string Annotation { get; set; }
        // Mandatory
        public string ISBN { get; set; }        
    }
}
