﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XMLibrary.Entities
{
    public class Newspaper : IEntity
    {
        // Mandatory
        public string Title { get; set; }
        public string PublicationPlace { get; set; }
        public string PublicationName { get; set; }
        public int PageCount { get; set; }
        public string Annotation { get; set; }
        // Mandatory
        public int Number { get; set; }
        public DateTime PublicationDate { get; set; }
        // Mandatory
        public string ISSN { get; set; }
    }
}
