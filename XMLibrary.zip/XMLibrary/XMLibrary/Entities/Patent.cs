﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XMLibrary.Entities
{
    public class Patent : IEntity
    {
        // Mandatory
        public string Title { get; set; }
        public List<Author> Authors { get; set; }
        public string Country { get; set; }
        // Mandatory
        public string RegistrationNumber { get; set; }
        public DateTime RegistrationDate { get; set; }
        public DateTime IssueDate { get; set; }
        public int PageCount { get; set; }
        public string Annotation { get; set; }
    }
}
