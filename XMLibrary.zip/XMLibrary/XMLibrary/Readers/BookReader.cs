﻿using System;
using System.Xml.Linq;
using XMLibrary.Entities;
using System.Linq;

namespace XMLibrary.Readers
{
    public class BookReader : IEntityReader
    {
       public override string EntityName
        {
            get
            {
                return "book";
            }
        }       
        public override IEntity Read(XElement bookEntity)
        {
            if (bookEntity == null)
            {
                throw new ArgumentNullException($"{nameof(bookEntity)} is null");
            }

            Book book = new Book
            {
                Title = GetElement(bookEntity, "title", true).Value,
                Authors = GetElement(bookEntity, "authors").Elements("author").Select(e => new Author
                {
                    FirstName = GetAttributeValue(e, "firstName"),
                    LastName = GetAttributeValue(e, "lastName")
                }).ToList(),
                PublicationPlace = GetAttributeValue(bookEntity, "publicationPlace"),
                PublicationName = GetAttributeValue(bookEntity, "publicationName", true),
                PublicationYear = int.Parse(GetAttributeValue(bookEntity, "publicationYear")),
                PageCount = int.Parse(GetElement(bookEntity, "pageCount").Value),
                Annotation = GetElement(bookEntity, "annotation").Value,
                ISBN = GetAttributeValue(bookEntity, "isbn", true)
            };
            return book;
        }
    }
}
