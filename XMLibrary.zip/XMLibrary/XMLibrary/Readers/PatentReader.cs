﻿using System;
using System.Linq;
using System.Xml.Linq;
using XMLibrary.Entities;

namespace XMLibrary.Readers
{
    public class PatentReader : IEntityReader
    {
        public override string EntityName
        {
            get
            {
                return "patent";
            }
        }
        public override IEntity Read(XElement patentEntity)
        {
            if (patentEntity == null)
            {
                throw new ArgumentNullException($"{nameof(patentEntity)} is null");
            }

            Patent patent = new Patent
            {
                Title = GetElement(patentEntity, "title").Value,
                Authors = GetElement(patentEntity, "authors").Elements("author").Select(e => new Author
                {
                    FirstName = GetAttributeValue(e, "firstName"),
                    LastName = GetAttributeValue(e, "lastName")
                }).ToList(),
                Country = GetAttributeValue(patentEntity, "country"),
                RegistrationNumber = GetAttributeValue(patentEntity, "registrationNumber"),
                RegistrationDate = DateTime.Parse(GetAttributeValue(patentEntity, "registrationDate")),
                IssueDate = DateTime.Parse(GetAttributeValue(patentEntity, "issueDate")),
                PageCount = int.Parse(GetElement(patentEntity, "pageCount").Value),
                Annotation = GetElement(patentEntity, "annotation").Value,                
            };
            return patent;
        }
    }
}
