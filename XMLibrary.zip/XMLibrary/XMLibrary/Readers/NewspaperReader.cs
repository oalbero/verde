﻿using System;
using System.Xml.Linq;
using XMLibrary.Entities;

namespace XMLibrary.Readers
{
    public class NewspaperReader : IEntityReader
    {
        public override string EntityName
        {
            get
            {
                return "newspaper";
            }
        }
        public override IEntity Read(XElement newspaperEntity)
        {
            if (newspaperEntity == null)
            {
                throw new ArgumentNullException($"{nameof(newspaperEntity)} is null");
            }

            Newspaper newspaper = new Newspaper
            {
                Title = GetElement(newspaperEntity, "title", true).Value,
                PublicationPlace = GetAttributeValue(newspaperEntity, "publicationPlace"),
                PublicationName = GetAttributeValue(newspaperEntity, "publicationName"),
                PageCount = int.Parse(GetElement(newspaperEntity, "pageCount").Value),
                Annotation = GetElement(newspaperEntity, "annotation").Value,
                Number = int.Parse(GetAttributeValue(newspaperEntity, "number", true)),
                PublicationDate = DateTime.Parse(GetAttributeValue(newspaperEntity, "publicationDate")),
                ISSN = GetAttributeValue(newspaperEntity, "issn", true)
            };
            return newspaper;
        }
    }
}
