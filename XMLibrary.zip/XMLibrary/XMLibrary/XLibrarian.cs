﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using XMLibrary.Entities;
using XMLibrary.Readers;
using XMLibrary.Writers;

namespace XMLibrary
{
    public class XLibrarian
    {
        private static string elementName = "library";
        private readonly IDictionary<string, IEntityReader> readers;
        private readonly IDictionary<Type, IEntityWriter> writers;

        public XLibrarian()
        {
            readers = new Dictionary<string, IEntityReader>();
            writers = new Dictionary<Type, IEntityWriter>();
        }

        public void AddReaders(params IEntityReader[] entityReader)
        {
            foreach (var r in entityReader)
            {
                readers.Add(r.EntityName, r);
            }
        }

        public void AddWriters(params IEntityWriter[] entityWriter)
        {
            foreach (var w in entityWriter)
            {
                writers.Add(w.Entity, w);
            }
        }       
        public IEnumerable<IEntity> ReadAllEntities(TextReader input)
        {
            using (XmlReader xmlReader = XmlReader.Create(input, new XmlReaderSettings
            {
                IgnoreWhitespace = true,
                IgnoreComments = true,                
            }))
            {
                xmlReader.ReadToFollowing(elementName);
                xmlReader.ReadStartElement();
                do
                {
                    while (xmlReader.NodeType == XmlNodeType.Element)
                    {
                        var node = XNode.ReadFrom(xmlReader) as XElement;
                        IEntityReader reader;
                        if (readers.TryGetValue(node.Name.LocalName, out reader))
                        {
                            yield return reader.Read(node);
                        }
                        else
                        {
                            throw new Exception($"Unknown element: {node.Name.LocalName}");
                        }
                    }
                } while (xmlReader.Read());
            }
        }
        public IEnumerable<IEntity> ReadEntityByTitle(TextReader input, string title)
        {
            using (XmlReader xmlReader = XmlReader.Create(input, new XmlReaderSettings
            {
                IgnoreWhitespace = true,
                IgnoreComments = true,
            }))
            {
                xmlReader.ReadToFollowing(elementName);
                xmlReader.ReadStartElement();
                do
                {
                    while (xmlReader.NodeType == XmlNodeType.Element)
                    {
                        var node = XNode.ReadFrom(xmlReader) as XElement;
                        IEntityReader reader;
                        if (readers.TryGetValue(node.Name.LocalName, out reader))
                        {
                            if(node.Descendants().ElementAt(0).Value == title)                            
                            yield return reader.Read(node);
                        }
                        else
                        {
                            throw new Exception($"Unknown element: {node.Name.LocalName}");
                        }
                    }
                } while (xmlReader.Read());
            }
        }
        public IEntity ReadBook(TextReader input)
        {
            using (XmlReader xmlReader = XmlReader.Create(input, new XmlReaderSettings
            {
                IgnoreWhitespace = true,
                IgnoreComments = true,

            }))
           {
                xmlReader.ReadToFollowing(elementName);
                xmlReader.ReadStartElement();

                var node = XNode.ReadFrom(xmlReader) as XElement;
                BookReader reader = new BookReader();
                IEntity book = reader.Read(node);
                return book;
            }
        }
        public void WriteBook(TextWriter output, Book book)
        {
            using (XmlWriter xmlWriter = XmlWriter.Create(output, new XmlWriterSettings()))
            {

                xmlWriter.WriteStartDocument();
                xmlWriter.WriteStartElement(elementName);
                BookWriter writer = new BookWriter();
                writer.Write(xmlWriter, book);
                xmlWriter.WriteEndElement();
            }
        }
        public IEntity ReadEntity(TextReader input, IEntity entity)
        {
            using (XmlReader xmlReader = XmlReader.Create(input, new XmlReaderSettings
            {
                IgnoreWhitespace = true,
                IgnoreComments = true,

            }))
            {
                xmlReader.ReadToFollowing(elementName);
                xmlReader.ReadStartElement();

                var node = XNode.ReadFrom(xmlReader) as XElement;

                IEntityReader reader = null;
                Type entityType = entity.GetType();
                if (entityType == typeof(Book))
                {
                    reader = new BookReader();
                }
                else if (entityType == typeof(Newspaper))
                {
                    reader = new NewspaperReader();
                }
                else if (entityType == typeof(Patent))
                {
                    reader = new PatentReader();
                }                
                IEntity entiry = reader.Read(node);
                return entity;
            }
        }
        public void WriteEntity(TextWriter output, IEntity entity)
        {
            using (XmlWriter xmlWriter = XmlWriter.Create(output, new XmlWriterSettings()))
            {

                xmlWriter.WriteStartDocument();
                xmlWriter.WriteStartElement(elementName);

                IEntityWriter writer = null;
                Type entityType = entity.GetType();
                if (entityType == typeof(Book))
                {
                    writer = new BookWriter();
                }
                else if (entityType == typeof(Newspaper))
                {
                    writer = new NewspaperWriter();
                }
                else if (entityType == typeof(Patent))
                {
                    writer = new PatentWriter();
                }
                writer.Write(xmlWriter, entity);

                xmlWriter.WriteEndElement();
            }
        }
        public void WriteAllEntities(TextWriter output, IEnumerable<IEntity> entities)
        {
            using (XmlWriter xmlWriter = XmlWriter.Create(output, new XmlWriterSettings()))
            {
                xmlWriter.WriteStartDocument();
                xmlWriter.WriteStartElement(elementName);
                foreach (var e in entities)
                {
                    IEntityWriter writer;
                    if (writers.TryGetValue(e.GetType(), out writer))
                    {
                        writer.Write(xmlWriter, e);
                    }
                    else
                    {
                        throw new Exception($"Cannot find entity writer {e.GetType().FullName}");
                    }
                }
                xmlWriter.WriteEndElement();
            }
        }       
        public void WriteToFile(XElement xString, string fileName)
        {
            using (var writer = XmlWriter.Create(
               new FileStream(fileName, FileMode.Create), new XmlWriterSettings { Indent = true }))
            {
                xString.WriteTo(writer);
            }
        }
        public string ReadFromFile(string fileName)
        {
            string text;

            using (var reader = XmlReader.Create(
               new FileStream(fileName, FileMode.Open, FileAccess.Read)))
            {
                text = reader.ReadContentAsString();
            }
            return text;
        }
    }
}
