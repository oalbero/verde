﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XMLibrary
{
    public interface IEntity
    {

    }
}
