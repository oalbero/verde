﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Xml.Linq;

namespace XMLibrary
{
    public abstract class IEntityReader
    {
        public abstract IEntity Read(XElement e);
        public abstract string EntityName { get; }  
        protected string GetAttributeValue(XElement element, string name, bool isMandatory = false)
        {
            var attribute = element.Attribute(name);
            if (string.IsNullOrEmpty(attribute?.Value) && isMandatory)
            {
                throw new Exception($"Value of {name} is missing.");
            }
            return attribute?.Value;
        }
        protected XElement GetElement(XElement parent, string name, bool isMandatory = false)
        {
            var element = parent.Element(name);
            if (string.IsNullOrEmpty(element?.Value) && isMandatory)
            {
                throw new Exception($"Value of {name} is missing.");
            }
            return element;
        }
    }
}
