﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace XMLibrary
{
    public abstract class IEntityWriter
    {
        public abstract Type Entity { get; }
        public abstract void Write(XmlWriter writer, IEntity e);       
        protected void AddAttribute(XElement element, string name, string value, bool isMandatory = false)
        {
            if (string.IsNullOrEmpty(value) && isMandatory)
            {
                throw new Exception($"Value of mandatory attribute \"{name}\" is null or empty");
            }

            element.SetAttributeValue(name, value);
        }
        protected void AddElement(XElement element, string name, object value, bool isMandatory = false)
        {
            if (value == null && isMandatory)
            {
                throw new Exception($"Value of mandatory element \"{name}\" is null");
            }

            var newElement = new XElement(name, value);
            element.Add(newElement);
        }
    }
}
