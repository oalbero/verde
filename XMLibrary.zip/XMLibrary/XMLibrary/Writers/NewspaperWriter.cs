﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using XMLibrary.Entities;

namespace XMLibrary.Writers
{
    public class NewspaperWriter : IEntityWriter
    {
        public override Type Entity
        {
            get
            {
                return typeof(Newspaper);
            }
        }
        public override void Write(XmlWriter xmlWriter, IEntity entity)
        {
            Newspaper newspaper = entity as Newspaper;
            if (newspaper == null)
            {
                throw new ArgumentException($"{nameof(entity)} is null or not of type {nameof(Newspaper)}");
            }
            XElement element = new XElement("newspaper");
            AddElement(element, "title", newspaper.Title, true);            
            AddAttribute(element, "publicationPlace", newspaper.PublicationPlace);
            AddAttribute(element, "publicationName", newspaper.PublicationName);           
            AddElement(element, "pageCount", newspaper.PageCount.ToString());            
            AddElement(element, "annotation", newspaper.Annotation);           
            AddAttribute(element, "publicationDate", newspaper.PublicationDate.ToShortDateString());
            AddAttribute(element, "issn", newspaper.ISSN, true);
            AddAttribute(element, "number", newspaper.Number.ToString(), true);            
            element.WriteTo(xmlWriter);
        }
    }
}
