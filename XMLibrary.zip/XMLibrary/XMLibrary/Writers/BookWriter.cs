﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using XMLibrary.Entities;

namespace XMLibrary.Writers
{
    public class BookWriter : IEntityWriter
    {
        public override Type Entity
        {
            get
            {
                return typeof(Book);
            }
        }
        public override void Write(XmlWriter xmlWriter, IEntity entity)
        {
            Book book = entity as Book;
            if (book == null)
            {
                throw new ArgumentException($"{nameof(entity)} is null or not of type {nameof(Book)}");
            }
            XElement element = new XElement("book");
            AddElement(element, "title", book.Title, true);
            AddElement(element, "authors",
                book.Authors?.Select(a => new XElement("author",
                    new XAttribute("firstName", a.FirstName),
                    new XAttribute("lastName", a.LastName)
                ))
            );
            AddAttribute(element, "publicationPlace", book.PublicationPlace);
            AddAttribute(element, "publicationName", book.PublicationName, true);
            AddAttribute(element, "publicationYear", book.PublicationYear.ToString());
            AddElement(element, "pageCount", book.PageCount.ToString());
            AddAttribute(element, "isbn", book.ISBN, true);
            AddElement(element, "annotation", book.Annotation);
            element.WriteTo(xmlWriter);
        }
    }
}
