﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using XMLibrary.Entities;

namespace XMLibrary.Writers
{
    public class PatentWriter : IEntityWriter
    {
        public override Type Entity
        {
            get
            {
                return typeof(Patent);
            }
        }
        public override void Write(XmlWriter xmlWriter, IEntity entity)
        {
            Patent patent = entity as Patent;
            if (patent == null)
            {
                throw new ArgumentException($"{nameof(entity)} is null or not of type {nameof(Patent)}");
            }
            XElement element = new XElement("patent");
            AddElement(element, "title", patent.Title);
            AddElement(element, "authors",
                patent.Authors?.Select(a => new XElement("author",
                    new XAttribute("firstName", a.FirstName),
                    new XAttribute("lastName", a.LastName)
                ))
            );
            AddAttribute(element, "country", patent.Country);
            AddAttribute(element, "registrationNumber", patent.RegistrationNumber);
            AddAttribute(element, "registrationDate", patent.RegistrationDate.ToShortDateString());
            AddAttribute(element, "issueDate", patent.IssueDate.ToShortDateString());
            AddElement(element, "pageCount", patent.PageCount.ToString());            
            AddElement(element, "annotation", patent.Annotation);
            element.WriteTo(xmlWriter);
        }
    }
}
