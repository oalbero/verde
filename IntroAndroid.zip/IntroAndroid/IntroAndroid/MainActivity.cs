﻿using Android.App;
using Android.OS;
using Android.Support.V7.App;
using Android.Runtime;
using Android.Widget;
using TimeHelper;

namespace IntroAndroid
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        Button clickMe;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.activity_main);

            clickMe = FindViewById<Button>(Resource.Id.button1);
            clickMe.Click += clickMe_Click;
        }
        private void clickMe_Click(object sender, System.EventArgs e)
        {
            TextView tvText = FindViewById<TextView>(Resource.Id.textView1);
            EditText nameText = FindViewById<EditText>(Resource.Id.editText1); 
            tvText.Text = Clocker.MakeHelloAtTime(nameText.Text);
        }
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}