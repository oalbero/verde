﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication.Controllers
{
    public class Index : Controller
    {
        // GET: Index
        public ActionResult GetIndex()
        {
            return View();
        }
    }
}