﻿using LinqToDB.Mapping;

namespace Linq2dbModel.Models
{
    [Table("[dbo].[CustomerDemographics]")]
    public class CustomerDemographic
    {
        [PrimaryKey]
        [Identity]
        [Column("CustomerTypeID")]
        public int CustomerTypeID { get; set; }

        [Column("CustomerDescription")]
        public string CustomerDescription { get; set; }
    }
}
