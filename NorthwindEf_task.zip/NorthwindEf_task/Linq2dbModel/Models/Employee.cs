﻿using LinqToDB.Mapping;

namespace Linq2dbModel.Models
{
    [Table("[dbo].[Employees]")]
    public class Employee
    {
        [PrimaryKey]
        [Identity]
        [Column("EmployeeID")]
        public int EmployeeId { get; set; }

        [Column("LastName")]
        public string LastName { get; set; }

        [Column("FirstName")]
        public string FirstName { get; set; }
    }
}
