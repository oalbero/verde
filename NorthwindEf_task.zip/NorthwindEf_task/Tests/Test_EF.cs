﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NorthwindEf_task.DbContext;

namespace Tests
{
    [TestClass]
    public class Test_EF
    {
        [TestMethod]
        public void TestEntity()
        {
            /*using (var context = new ModelNorthwind())
            {
                foreach (var cat in context.Categories)
                {
                    Console.WriteLine($"{cat.CategoryID}");
                }
            }*/
        }
    }
}
