﻿using Linq2dbModel;
using Linq2dbModel.Models;
using LinqToDB;
using LinqToDB.Data;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace TestLinq2db
{
    [TestFixture]
    public class TestModelsLinq2db
    {
        private NorthwindConnection connection;
        [SetUp]
        public void Setup()
        {
            connection = new NorthwindConnection("ModelNorthwind");
        }
        [Test]
        public void TestProductListWithCategoriesAndSuppliers()
        {
            foreach (var product in connection.Products.LoadWith(p => p.Category).LoadWith(p => p.Supplier).ToList())
            {
                Console.WriteLine($"Product name: {product.ProductName}; Category: {product.Category?.CategoryName}; Supplier: {product.Supplier?.ContactName}");
            }
        }
        [Test]
        public void TestEmployeeListWithRegions()
        {
            var query = from e in connection.Employees
                        join et in connection.EmployeeTerritories on e.EmployeeId equals et.EmployeeId into el
                        from w in el.DefaultIfEmpty()
                        join t in connection.Territories on w.TerritoryId equals t.TerritoryId into zl
                        from z in zl.DefaultIfEmpty()
                        join r in connection.Regions on z.RegionId equals r.RegionId into kl
                        from k in kl.DefaultIfEmpty()
                        select new { e.FirstName, e.LastName, Region = k };
            query = query.Distinct();

            foreach (var record in query.ToList())
            {
                Console.WriteLine($"Employee: {record.FirstName} {record.LastName}; Region: {record.Region?.RegionDescription}");
            }
        }
        [Test]
        public void TestStatisticsOfEmployeesFromRegions()
        {
            var query = from r in connection.Regions
                        join t in connection.Territories on r.RegionId equals t.RegionId into kl
                        from k in kl.DefaultIfEmpty()
                        join et in connection.EmployeeTerritories on k.TerritoryId equals et.TerritoryId into zl
                        from z in zl.DefaultIfEmpty()
                        join e in connection.Employees on z.EmployeeId equals e.EmployeeId into dl
                        from d in dl.DefaultIfEmpty()
                        select new { Region = r, d.EmployeeId };
            var result = from row in query.Distinct()
                         group row by row.Region into ger
                         select new { RegionDescription = ger.Key.RegionDescription, EmployeesCount = ger.Count(e => e.EmployeeId != 0) };

            foreach (var record in result.ToList())
            {
                Console.WriteLine($"Region: {record.RegionDescription}; Employees count: {record.EmployeesCount}");
            }
        }
        [Test]
        public void TestEmployeesWithShippers()
        {
            var query = (from e in connection.Employees
                         join o in connection.Orders on e.EmployeeId equals o.EmployeeId into el
                         from w in el.DefaultIfEmpty()
                         join s in connection.Shippers on w.ShipperId equals s.ShipperId into zl
                         from z in zl.DefaultIfEmpty()
                         select new { e.EmployeeId, e.FirstName, e.LastName, z.CompanyName }).Distinct().OrderBy(t => t.EmployeeId);

            foreach (var record in query.ToList())
            {
                Console.WriteLine($"Employee: {record.FirstName} {record.LastName} Shipper: {record.CompanyName}");
            }
        }
        [Test]
        public void TestAddNewEmployeeWithRegion()
        {
            Employee newEmployee = new Employee { FirstName = "Jhon", LastName = "Doe" };
            try
            {
                connection.BeginTransaction();
                newEmployee.EmployeeId = Convert.ToInt32(connection.InsertWithIdentity(newEmployee));
                connection.Territories.Where(t => t.TerritoryDescription.Length <= 5)
                    .Insert(connection.EmployeeTerritories, t => new EmployeeTerritory { EmployeeId = newEmployee.EmployeeId, TerritoryId = t.TerritoryId });
               connection.CommitTransaction();
            }
            catch
            {
                connection.RollbackTransaction();
            }
        }
        [Test]
        public void TestMoveProductFromCategory()
        {
            int updatedCount = connection.Products.Update(p => p.CategoryId == 2, pr => new Product
            {
                CategoryId = 1
            });

            Console.WriteLine(updatedCount);
        }
        [Test]
        public void TestInsertProductsWithSuppliersAndCategories()
        {
            var products = new List<Product>
            {
                new Product
                {
                    ProductName = "Coffee",
                    Category = new Category {CategoryName = "Drinks"},
                    Supplier = new Supplier {CompanyName = "Parisian"}
                },
                new Product
                {
                    ProductName = "Arabica coffee",
                    Category = new Category {CategoryName = "Drinks"},
                    Supplier = new Supplier {CompanyName = "Parisian"}
                }
            };

            try
            {
                connection.BeginTransaction();
                //pass ids to products list
                foreach (var product in products)
                {
                    var category = connection.Categories.FirstOrDefault(c => c.CategoryName == product.Category.CategoryName);
                    product.CategoryId = category?.CategoryId ?? Convert.ToInt32(connection.InsertWithIdentity(
                                             new Category
                                             {
                                                 CategoryName = product.Category.CategoryName
                                             }));
                    var supplier = connection.Suppliers.FirstOrDefault(s => s.CompanyName == product.Supplier.CompanyName);
                    product.SupplierId = supplier?.SupplierId ?? Convert.ToInt32(connection.InsertWithIdentity(
                                             new Supplier
                                             {
                                                 CompanyName = product.Supplier.CompanyName
                                             }));
                }

                connection.BulkCopy(products);
                connection.CommitTransaction();
            }
            catch
            {
                connection.RollbackTransaction();
            }
        }
        [Test]
        public void TestReplaceOrdersWithNullShippedDate()
        {
            var orderDetails = connection.OrderDetails.LoadWith(od => od.Order)
               .Where(od => od.Order.ShippedDate == null).ToList();
            foreach (var orderDetail in orderDetails)
            {
                connection.OrderDetails.LoadWith(od => od.Product).Update(od => od.OrderId == orderDetail.OrderId && od.ProductId == orderDetail.ProductId,
                    od => new Order_Detail
                    {
                        ProductId = connection.Products.First(p => !connection.OrderDetails.Where(t => t.OrderId == od.OrderId)
                                .Any(t => t.ProductId == p.ProductId) && p.CategoryId == od.Product.CategoryId).ProductId
                    });
            }
        }

        [TearDown]
        public void Dispose()
        {
            connection.Dispose();
        }
    }

}
