﻿namespace MyIoC
{
	[Export]
	public class Logger
	{
	}
}