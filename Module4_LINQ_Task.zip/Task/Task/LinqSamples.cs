﻿// Copyright © Microsoft Corporation.  All Rights Reserved.
// This code released under the terms of the 
// Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
//
//Copyright (C) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Linq;
using SampleSupport;
using Task.Data;

// Version Mad01

namespace SampleQueries
{
	[Title("LINQ Module")]
	[Prefix("Linq")]
	public class LinqSamples : SampleHarness
	{

		private DataSource dataSource = new DataSource();
     
        [Category("Restriction Operators")]
        [Title("Where - Task 1")]
        [Description("Select all customers whose order's sum is greater than X")]
        public void Linq001()
        {
            decimal x = 12000;
            var customersList = dataSource.Customers
                .Where(c => c.Orders.Sum(o => o.Total) > x)
                .Select(c => new
                {
                    CustomerId = c.CustomerID,
                    TotalOrdersSum = c.Orders.Sum(o => o.Total)
                });

            ObjectDumper.Write($"Greater than {x}");
            foreach (var customer in customersList)
            {
                ObjectDumper.Write(
                    string.Format($"CustomerId: {customer.CustomerId} TotalOrdersSum: {customer.TotalOrdersSum}\n"));
            }
            x =9500;
            ObjectDumper.Write($"Greater than {x}");
            foreach (var customer in customersList)
            {
                ObjectDumper.Write(
                    string.Format($"CustomerId: {customer.CustomerId} TotalOrdersSum: {customer.TotalOrdersSum}\n"));
            }
        }
        [Category("Restriction Operators")]
        [Title("Where - Task 2")]
        [Description("Select all customers whose supplires are from the same country and city")]
        public void Linq002()
        {
            // without grouping
            var customerList =
                from cust in dataSource.Customers
                from suppl in dataSource.Suppliers
                where cust.Country == suppl.Country && cust.City == suppl.City
                select new { cust.CustomerID };

            ObjectDumper.Write($"Customers whose suppliers are from the same country and city.");
            foreach (var customer in customerList)
            {
                ObjectDumper.Write(
                    string.Format($"CustomerId: {customer.CustomerID}\n"));
            }
            // with grouping
            var customerList2 =
                from cust in dataSource.Customers
                from suppl in dataSource.Suppliers
                where cust.City == suppl.City && cust.Country == suppl.Country
                group cust by cust.CustomerID into customers
                select new { CustomerId = customers.Key };

            ObjectDumper.Write($"\nGrouping \nCustomers whose suppliers are from the same country and city.");
            foreach (var customer in customerList2)
            {
                ObjectDumper.Write(
                    string.Format($"CustomerId: {customer.CustomerId}\n"));
            }
        }
        [Category("Restriction Operators")]
        [Title("Where - Task 3")]
        [Description("Select all customers who have orders greather than value X")]
        public void Linq003()
        {
            // with methods
            decimal x = 8000;
            var customersList = dataSource.Customers
                .Where(c => c.Orders.Any(o => o.Total > x))
                .Select(c => new
                {
                    CustomerId = c.CustomerID,
                });

            ObjectDumper.Write($"Method syntax: Customers with order total greater than {x}");
            foreach (var customer in customersList)
            {
                ObjectDumper.Write(
                    string.Format($"CustomerId: {customer.CustomerId}\n"));
            }
            // with expressions
            x = 8000;
            var customersList2 =
                from customer in dataSource.Customers
                group customer by customer.CustomerID into custGr
                where custGr.All(c => c.Orders.Any(o => o.Total > x)) 
                select  new {  custGr.Key };
            ObjectDumper.Write($"Extension syntax: Customers with order total greater than {x}");
            foreach (var customer in customersList2)
            {
                ObjectDumper.Write(
                   string.Format($"CustomerId: {customer.Key}\n"));
            }
        }
        [Category("Restriction Operators")]
        [Title("OrderBy - Task 4")]
        [Description("Select customers by their start year and month.")]
        public void Linq004()
        {
            // with methods            
            var customersList = dataSource.Customers               
                .Select(c => new
                {
                    CustomerId = c.CustomerID,                   
                    FirstOrderYear = c.Orders.OrderBy(o => o.OrderDate).FirstOrDefault().OrderDate.Year,
                    FirstOrderMonth = c.Orders.OrderBy(o => o.OrderDate).FirstOrDefault().OrderDate.Month
                });

            ObjectDumper.Write($"Method syntax: Customer with first order date and month.");
            foreach (var customer in customersList)
            {
                ObjectDumper.Write(
                    string.Format($"CustomerId: {customer.CustomerId}, FirstOrderYear: {customer.FirstOrderYear} FirstOrderMonth: {customer.FirstOrderMonth}\n"));
            }
        }
        [Category("Ordering Operators")]
        [Title("OrderBy - Task 5")]
        [Description("Select customers by their start year and month order by year, month, profit, name.")]
        public void Linq005()
        {
            // with methods            
            var customersList = dataSource.Customers
                .Where(c => c.Orders.Any())
                .Select(c => new
                {
                    CustomerId = c.CustomerID,
                    Name = c.CompanyName,
                    Profit = c.Orders.Sum(o => o.Total),
                    FirstOrderDate = c.Orders.OrderByDescending(o => o.OrderDate).First().OrderDate.Date,
                })                
                .OrderBy(c => c.FirstOrderDate)
                .ThenByDescending(c => c.Profit)
                .ThenByDescending(c => c.Name);

            ObjectDumper.Write($"Method syntax: Customer with first order date and month order by profit and name.");
            foreach (var customer in customersList)
            {
                ObjectDumper.Write(
                    string.Format($"CustomerId: {customer.CustomerId}, FirstOrderDate: {customer.FirstOrderDate} " +
                    $"Profit: {customer.Profit}, Name: {customer.Name}"));
            }
        }
        [Category("Element Operators")]
        [Title("FirstOrDefalut - Task 6")]
        [Description("Select customers by non-digit zip code or with empty reagon or without phone code operator.")]
        public void Linq006()
        {
            // with methods            
            var customersList = dataSource.Customers
                 .Where(c => c.PostalCode != null && c.PostalCode.Any(sym => sym < '0' || sym > '9') ||
                 String.IsNullOrEmpty(c.Region) ||
                 !c.Phone.StartsWith("("))
                .Select(c => new
                {
                    CustomerId = c.CustomerID,                   
                    PostalCode = c.PostalCode,
                    Region = c.Region,
                    Phone = c.Phone
                });

            ObjectDumper.Write($"Method syntax: non-digit zip code or with empty reagon or without phone code operator.");
            foreach (var customer in customersList)
            {
                ObjectDumper.Write(
                    string.Format($"CustomerId: {customer.CustomerId}, PostalCode: {customer.PostalCode} " +
                    $"Region: {customer.Region}, Phone: {customer.Phone}"));
            }
        }
        [Category("Grouping Operators")]
        [Title("Group - Task 7")]
        [Description("Select products group by category group by availability in stock order by price")]
        public void Linq007()
        {
            // with expressions           
            var productCatStockGroup =
                from product in dataSource.Products
                group product by product.Category into catGroup
                from stockGroup in
                    (from product in catGroup
                     orderby product.UnitPrice
                     group product by product.UnitsInStock
                     )
                group stockGroup by catGroup.Key;

            ObjectDumper.Write($"Expression syntax: Products group by category group by availability in stock order by price");
            foreach (var catGroup in productCatStockGroup)
            {
                ObjectDumper.Write($"Category = {catGroup.Key}");
                foreach (var stockGroup in catGroup)
                {
                    ObjectDumper.Write($"Stocks in group: {stockGroup.Key}");
                    foreach (var pr in stockGroup)
                    {
                        ObjectDumper.Write($"\t Product: {pr.ProductName}");
                    }                   
                }
                ObjectDumper.Write("\n");
            }
        }
        [Category("Grouping Operators")]
        [Title("Group - Task 8")]
        [Description("Group products by price as Cheap, Average, Expensive.")]
        public void Linq008()
        {
            // with methods      
            var averagePrice =
                 dataSource.Products.Select(p => p.UnitPrice).Average();
            var minPrice =
                dataSource.Products.Select(p => p.UnitPrice).Min();
            var maxPrice =
                dataSource.Products.Select(p => p.UnitPrice).Max();
            ObjectDumper.Write($"Average price: {averagePrice}");
            ObjectDumper.Write($"Min price: {minPrice}");
            ObjectDumper.Write($"Max price: {maxPrice}");

            decimal lowAverageBoundary = 25;
            decimal averageExpensiveBoundary = 40;

            var productPriceGroups = dataSource.Products                
                .GroupBy(p => p.UnitPrice < lowAverageBoundary ? "Cheap"
                    : p.UnitPrice < averageExpensiveBoundary ? "Average" : "Expensive");
                
            foreach (var group in productPriceGroups)
            {
                ObjectDumper.Write($"{group.Key}:");
                foreach (var product in group)
                {
                    ObjectDumper.Write($"\tProduct: {product.ProductName} \tPrice: {product.UnitPrice}\n");
                }
            }
        }
        [Category("Grouping Operators")]
        [Title("Group - Task 9")]
        [Description(" Select average profit by all customers for a city and average order count per customer for a city")]
        public void Linq009()
        {
            // with methods      
            var averageValues = dataSource.Customers
               .GroupBy(c => c.City)
               .Select(c => new
               {
                   City = c.Key,
                   Intensity = c.Average(p => p.Orders.Length),
                   AverageProfit = c.Average(p => p.Orders.Sum(o => o.Total))
               })
               .OrderBy(c => c.City)
               ;

            var averageValues2 = from customer in dataSource.Customers
                                 orderby customer.City
                                 group customer by customer.City into cusGr                                
                                 select new
                                 {
                                     City = cusGr.Key,
                                     Intensity = cusGr.Average(c => c.Orders.Length),
                                     AverageProfit = cusGr.Average(c => c.Orders.Sum(o => o.Total))
                                 };
                    
            foreach (var group in averageValues)
            {
                ObjectDumper.Write($"City: {group.City}");
                ObjectDumper.Write($"\tIntensity: {group.Intensity}");
                ObjectDumper.Write($"\tAverage Profit: {group.AverageProfit}");
            }
            ObjectDumper.Write("Expressions:");
            foreach (var group in averageValues2)
            {
                ObjectDumper.Write($"City: {group.City}");
                ObjectDumper.Write($"\tIntensity: {group.Intensity}");
                ObjectDumper.Write($"\tAverage Profit: {group.AverageProfit}");
            }
        }
        [Category("Grouping Operators")]
        [Title("Group - Task 10")]
        [Description("List statistics of customers by years, by months, and by months in year")]
        public void Linq010()
        {
           var statistics = dataSource.Customers
                .Select(c => new
                {
                    c.CustomerID,
                    MonthsStatistics = c.Orders.GroupBy(o => o.OrderDate.Month)
                                        .Select(s => new { Month = s.Key, OrdersCount = s.Count() }),
                    YearsStatistics = c.Orders.GroupBy(o => o.OrderDate.Year)
                                        .Select(s => new { Year = s.Key, OrdersCount = s.Count() }),
                    YearMonthStatistics = c.Orders
                                        .GroupBy(o => new { o.OrderDate.Year, o.OrderDate.Month })
                                        .Select(s => new { s.Key.Year, s.Key.Month, OrdersCount = s.Count() })
                });

            foreach (var record in statistics)
            {
                ObjectDumper.Write($"CustomerId: {record.CustomerID}");
                ObjectDumper.Write("\tMonths statistic:\n");
                foreach (var ms in record.MonthsStatistics)
                {
                    ObjectDumper.Write($"\t\tMonth: {ms.Month} Orders count: {ms.OrdersCount}");
                }
                ObjectDumper.Write("\tYears statistic:\n");
                foreach (var ys in record.YearsStatistics)
                {
                    ObjectDumper.Write($"\t\tYear: {ys.Year} Orders count: {ys.OrdersCount}");
                }
                ObjectDumper.Write("\tYear and month statistic:\n");
                foreach (var yms in record.YearMonthStatistics)
                {
                    ObjectDumper.Write($"\t\tYear: {yms.Year} Month: {yms.Month} Orders count: {yms.OrdersCount}");
                }
            }
        }
    }
}
