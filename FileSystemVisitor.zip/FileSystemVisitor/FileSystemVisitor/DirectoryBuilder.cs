﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace FileSystemVisitor
{
    public static class DirectoryBuilder
    {
        static string[] fileTypes = new string[] { ".txt", ".json", ".file", ".rtf" };
        public static void BuildDirectorySystem(string startDir, string rootFolderName)
        {
            Console.WriteLine("Creating testing directories...");

            string testDir = Path.Combine(startDir, rootFolderName);
            if (Directory.Exists(testDir))
            {
                Directory.Delete(testDir, true);
            }
            Directory.CreateDirectory(testDir);

            for (int i = 1; i < 5; i++)
            {
                string subDir = String.Concat("randomfolder", i);
                Directory.CreateDirectory(Path.Combine(testDir, subDir));

                foreach (string d in fileTypes)
                {
                    if (!File.Exists(Path.Combine(subDir, i.ToString() + d)))
                    {
                        File.Create(Path.Combine(testDir, subDir, i.ToString() + d));
                    }
                }
            }
        }
    }
}
