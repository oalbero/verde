﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace FileSystemVisitor
{
    public class FileSystemVisitor
    {
        public string RootPath { get; set; }
        public bool Abort { get; set; }
        public bool isSkipped;
        public Func<string, bool> filterBy;
        public FileSystemVisitor(string rootPath, Func<string, bool> filter = null)
        {
            RootPath = rootPath;
            filterBy = filter;            
        }

        public IEnumerable<String> Visit()
        {
            OnStart(this, new VisitorArgs());
            return Visit(RootPath);            
        }

        private IEnumerable<String> Visit(String path, bool isRoot = true)
        {
            foreach (var file in Directory.GetFiles(path))
            {
                var args = new VisitorArgs() { File = file };

                if (isSkipped)
                {
                    OnSkip(this, args);   
                    isSkipped = false;
                }
                else
                {
                    if (filterBy != null)
                    {
                        if (filterBy(file))
                        {
                            OnFilteredFileFound(this, args);
                            yield return file;
                        }
                    }
                    else
                    {
                        OnFileFound(this, args);
                        yield return file;
                    }
                }
                
                if (Abort)
                {
                    yield break;
                }
            }
            foreach (var folder in Directory.GetDirectories(path))
            {             
                var args = new VisitorArgs() { Folder = folder };
                if (isSkipped)
                {
                    OnSkip(this, args);
                    isSkipped = false;
                }
                else
                {
                    if (filterBy != null)
                    {
                        if (filterBy(folder))
                        {
                            OnFilteredFolderFound(this, args);
                            yield return folder;
                        }
                    }
                    else
                    {
                        OnFolderFound(this, args);
                        yield return folder;
                    }
                }
                
                if (Abort)
                {
                    yield break;
                }             
                foreach (var file in Visit(folder, false))
                {  
                    yield return file;
                }
            }
            if (isRoot)
            {
                OnFinish(this, new VisitorArgs());
            }
        }

        public event EventHandler<VisitorArgs> Start;
        public event EventHandler<VisitorArgs> Finish;
        public event EventHandler<VisitorArgs> Skip;
        public event EventHandler<VisitorArgs> FileFound;
        public event EventHandler<VisitorArgs> FolderFound;
        public event EventHandler<VisitorArgs> FilteredFileFound;
        public event EventHandler<VisitorArgs> FilteredFolderFound;

        private void OnStart(Object sender, VisitorArgs e)
        {
            Start?.Invoke(sender, e);
        }

        private void OnFinish(Object sender, VisitorArgs e)
        {
           Finish?.Invoke(sender, e);
        }
        public void OnSkip(Object sender, VisitorArgs e)
        {
            Skip?.Invoke(sender, e);
        }
        private void OnFileFound(Object sender, VisitorArgs e)
        {
            FileFound?.Invoke(sender, e);
        }
        private void OnFilteredFileFound(Object sender, VisitorArgs e)
        {
            FilteredFileFound?.Invoke(sender, e);
        }
        private void OnFolderFound(Object sender, VisitorArgs e)
        {
            FolderFound?.Invoke(sender, e);
        }
        private void OnFilteredFolderFound(Object sender, VisitorArgs e)
        {
            FilteredFolderFound?.Invoke(sender, e);
        }
    }
}
