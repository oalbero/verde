﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace FileSystemVisitor
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length < 2)
            {
                Console.WriteLine("Incorrect usage!\n./FileSystemVisitor {root_path} {abort_time_sec}");
                return;
            }
            else
            {
                var rootPath = args[0];
                var visitor = new FileSystemVisitor(rootPath, false, i => i.Contains("root"));
                var watcher = new FileSystemConsoleWatcher(visitor);

                int abortTime = Int32.Parse(args[1]);

                Task.Factory.StartNew(() => 
                {
                    Thread.Sleep(abortTime);
                    watcher.Abort = true;
                });

                foreach (var item in visitor.Visit())
                {
                    //Console.WriteLine($"Visited: {item}");
                    Thread.Sleep(1000);
                }                
            }

            Console.ReadLine();
        }
    }
}
