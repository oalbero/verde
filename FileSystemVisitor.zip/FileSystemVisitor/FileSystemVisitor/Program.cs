﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace FileSystemVisitor
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length < 3)
            {
                Console.WriteLine("Incorrect usage!\n./FileSystemVisitor {root_path} {abort__skip_time_sec} {skip_counter}");
                return;
            }
            else
            {
                var rootPath = args[0];
                var visitor = new FileSystemVisitor(rootPath, i => i.Contains("root"));
                var watcher = new FileSystemConsoleWatcher(visitor);

                int abortTime = Int32.Parse(args[1]);
                int skipCount = Int32.Parse(args[2]);

                Task.Factory.StartNew(() =>
                {
                    for (var i = 0; i < skipCount; i++)
                    {
                        Thread.Sleep(abortTime);
                        visitor.isSkipped = true;
                    }                    
                });


                //Task.Factory.StartNew(() =>
                //{
                //    Thread.Sleep(abortTime);
                //    watcher.Abort = true;
                //});

                foreach (var item in visitor.Visit())
                {
                    //Console.WriteLine($"Visited: {item}");
                    Thread.Sleep(1000);
                }                
            }

            Console.ReadLine();
        }
    }
}
