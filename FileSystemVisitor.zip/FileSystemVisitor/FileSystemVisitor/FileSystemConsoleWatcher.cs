﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FileSystemVisitor
{
    public class FileSystemConsoleWatcher
    {
        private readonly FileSystemVisitor _visitor;
        public bool Abort { get; set; }

        public FileSystemConsoleWatcher(FileSystemVisitor visitor)
        {
            _visitor = visitor;
            RegisterHandlers();
        }

        private void RegisterHandlers()
        {
            _visitor.Start += Start;
            _visitor.Finish += Finish;
            _visitor.FileFound += FileFound;
            _visitor.Skip += Skip;
            _visitor.FilteredFileFound += FilteredFileFound;
            _visitor.FolderFound += FolderFound;
            _visitor.FilteredFolderFound += FilteredFolderFound;
        }
        public void Start(Object sender, VisitorArgs e)
        {
            Console.WriteLine("Starting File System Traversal!");
        }

        public void Finish(Object sender, VisitorArgs e)
        {
            Console.WriteLine("Finished File System Traversal!");
        }

        public void FileFound(Object sender, VisitorArgs e)
        {
            if (Abort)
            {
                //e.Abort = true;
                if (sender is FileSystemVisitor)
                {
                    var visitor = sender as FileSystemVisitor;
                    visitor.Abort = true;
                }
                Console.WriteLine("Search Aborted!");
            }
            else
            {
                Console.WriteLine($"File Found: {e.File}");
            }
        }
        public void FilteredFileFound(Object sender, VisitorArgs e)
        {
            if (Abort)
            {
                //e.Abort = true;
                if (sender is FileSystemVisitor)
                {
                    var visitor = sender as FileSystemVisitor;
                    visitor.Abort = true;
                }
                Console.WriteLine("Search Aborted!");
            }
            else
            {
                Console.WriteLine($"Filtered file Found: {e.File}");
            }
        }
        public void FolderFound(Object sender, VisitorArgs e)
        {
            if (Abort)
            {
                //e.Abort = true;
                if (sender is FileSystemVisitor)
                {
                    var visitor = sender as FileSystemVisitor;
                    visitor.Abort = true;
                }
                Console.WriteLine("Search Aborted!");
            }
            else
            {
                Console.WriteLine($"Folder Found: {e.Folder}");
            }
        }
        public void FilteredFolderFound(Object sender, VisitorArgs e)
        {
            if (Abort)
            {
                //e.Abort = true;
                if (sender is FileSystemVisitor)
                {
                    var visitor = sender as FileSystemVisitor;
                    visitor.Abort = true;
                }
                Console.WriteLine("Search Aborted!");
            }
            else
            {
                Console.WriteLine($"Filtered Folder Found: {e.File}");
            }
        }
        public void Skip(Object sender, VisitorArgs e)
        {
            Console.WriteLine($"File skipped: {e.File}");
        }
    }
}
