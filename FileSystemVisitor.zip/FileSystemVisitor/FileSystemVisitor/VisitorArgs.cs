﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FileSystemVisitor
{
    public class VisitorArgs: EventArgs
    {
        //can be used for individual abortion
        public bool Skip { get; set; }
        public bool Abort { get; set; }
        public string  File { get; set; }
        public string Folder { get; set; }
    }
}
