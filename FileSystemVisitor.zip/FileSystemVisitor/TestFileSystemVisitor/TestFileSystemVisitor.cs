using FileSystemVisitor;
using NUnit.Framework;
using System.Diagnostics;
using System.IO;

namespace Tests
{
    public class Tests
    {
        static string rootPath;
        static FileSystemVisitor.FileSystemVisitor visitor;       
        string testDirName;

        [SetUp]
        public void Setup()
        {
            rootPath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            testDirName = "testFolder";
            DirectoryBuilder.BuildDirectorySystem(rootPath, testDirName);           
        }

        [Test]
        public void TestAllItemsCounts()
        {
            visitor = new FileSystemVisitor.FileSystemVisitor(Path.Combine(rootPath, testDirName), false, null);
            
            int expectedCount = 20;
            int actualCount = 0;
            foreach (var i in visitor.Visit())
            {
                actualCount++;
                Debug.WriteLine(i);
            }
            Assert.AreEqual(expectedCount, actualCount);
        }
        [Test]
        public void TestJsonItemsCount()
        {
            visitor = new FileSystemVisitor.FileSystemVisitor(Path.Combine(rootPath, testDirName), false, i=>i.EndsWith(".json"));
            
            int expectedCount = 4;
            int actualCount = 0;
            foreach (var i in visitor.Visit())
            {
                actualCount++;
                Debug.WriteLine(i);
            }
            Assert.AreEqual(expectedCount, actualCount);
        }
        [Test]
        public void TestFoldersCountWithNameRandomFolder2()
        {
            visitor = new FileSystemVisitor.FileSystemVisitor(Path.Combine(rootPath, testDirName), false, i => i.EndsWith("randomfolder2"));
            
            int expectedCount = 1;
            int actualCount = 0;
            foreach (var i in visitor.Visit())
            {
                actualCount++;
                Debug.WriteLine(i);
            }
            Assert.AreEqual(expectedCount, actualCount);
        }        
        [Test]
        public void TestForSkip()
        {
            // test if there isn't any element (should not be)
            visitor = new FileSystemVisitor.FileSystemVisitor(Path.Combine(rootPath, testDirName), true, null);

            if(visitor.Visit().GetEnumerator().MoveNext())
            {
                Assert.True(true);
            }            
        }
        [Test]
        public void TestNegativeForSkip()
        {
            // test if there are any elements (should be)
            visitor = new FileSystemVisitor.FileSystemVisitor(Path.Combine(rootPath, testDirName), false, null);

            if (visitor.Visit().GetEnumerator().MoveNext())
            {
                Assert.True(true);
            }
        }       
    }
}