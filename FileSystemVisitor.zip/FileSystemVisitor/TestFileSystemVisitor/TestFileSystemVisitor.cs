using FileSystemVisitor;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace Tests
{
    public class Tests
    {
        static string rootPath;
        static FileSystemVisitor.FileSystemVisitor visitor;       
        string testDirName;

        [SetUp]
        public void Setup()
        {
            rootPath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            testDirName = "testFolder";
            DirectoryBuilder.BuildDirectorySystem(rootPath, testDirName);           
        }

        [Test]
        public void TestItemsCounts()
        {
            visitor = new FileSystemVisitor.FileSystemVisitor(Path.Combine(rootPath, testDirName), null);
            IEnumerable<string> items = visitor.Visit();
            int expectedCount = 20;
            int actualCount = 0;
            foreach (var i in items)
            {
                actualCount++;
                Debug.WriteLine(i);
            }
            Assert.AreEqual(expectedCount, actualCount);
        }
        [Test]
        public void TestJsonItemsCount()
        {
            visitor = new FileSystemVisitor.FileSystemVisitor(Path.Combine(rootPath, testDirName), i=>i.Extension.Equals("json"));
            IEnumerable<string> items = visitor.Visit();
            int expectedCount = 4;
            int actualCount = 0;
            foreach (var i in items)
            {
                actualCount++;
                Debug.WriteLine(i);
            }
            Assert.AreEqual(expectedCount, actualCount);
        }
    }
}