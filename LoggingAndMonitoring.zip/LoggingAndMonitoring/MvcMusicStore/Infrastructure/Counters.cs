﻿using PerformanceCounterHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcMusicStore.Infrastructure
{
    [PerformanceCounterCategory(
        "MvcMusicStore",
        System.Diagnostics.PerformanceCounterCategoryType.MultiInstance,
        "MvcMusicStore")]
    public enum Counters
    {
        [PerformanceCounter(
            "Go to home page count",
            "Go to home page count",
            System.Diagnostics.PerformanceCounterType.NumberOfItems32)]
        GoToHome=1,

            [PerformanceCounter(
            "Go to login page count",
            "Go to login page count",
            System.Diagnostics.PerformanceCounterType.NumberOfItems32)]
        GoToLogin=2,

            [PerformanceCounter(
            "Go to store page count",
            "Go to store page count",
            System.Diagnostics.PerformanceCounterType.NumberOfItems32)]
        GoToStore=3
    }
}