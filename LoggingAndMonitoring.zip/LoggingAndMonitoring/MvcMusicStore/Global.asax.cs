﻿using Autofac;
using Autofac.Integration.Mvc;
using MvcMusicStore.Controllers;
using MvcMusicStore.Infrastructure;
using NLog;
using PerformanceCounterHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace MvcMusicStore
{
    public class MvcApplication : System.Web.HttpApplication
    {
        private readonly ILogger logger;
        static CounterHelper<Counters> counterHelper;

        static MvcApplication()
        {
            //counterHelper = PerformanceHelper.CreateCounterHelper<Counters>("Test Music Store Project");
        }
        public MvcApplication()
        {
            logger = LogManager.GetCurrentClassLogger();
        }
        protected void Application_Start()
        {
            var builder = new ContainerBuilder();
            builder.RegisterControllers(typeof(HomeController).Assembly);
            builder.Register(f => LogManager.GetLogger("ForControllers")).As<ILogger>();
            DependencyResolver.SetResolver(new AutofacDependencyResolver(builder.Build()));

            counterHelper = PerformanceHelper.CreateCounterHelper<Counters>("Test Music Store Project");

            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            logger.Info("Application started.");
           
            // Tu turn off logger, set globalThreshold="On" in NLog.config
            //LogManager.GlobalThreshold = LogLevel.Off;
        }
        protected void Application_Error()
        {
            var ex = Server.GetLastError();
            logger.Warn("This is from Global.asax");
            logger.Error(ex.StackTrace.ToString());
        }
    }
}
